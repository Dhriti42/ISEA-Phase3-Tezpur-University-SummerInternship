"""
Assignment 6: GUI-Based Multi-Client Chat Application Using TCP
client_gui.py  — Tkinter GUI client (reuses Assignment 5 socket logic)

Run on h2–h5 inside Mininet:
    python3 client_gui.py [server_ip] [port]
"""

import socket
import threading
import sys
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from datetime import datetime

# ─── Defaults ─────────────────────────────────────────────────────────────────
DEFAULT_HOST = '10.0.0.1'
DEFAULT_PORT = 5000

# ─── Colour / style constants ─────────────────────────────────────────────────
BG_DARK   = '#1e1e2e'
BG_MID    = '#2a2a3e'
BG_PANEL  = '#252538'
ACCENT    = '#7c6af7'
ACCENT2   = '#5b8dee'
TXT_WHITE = '#e8e8f0'
TXT_GREY  = '#9090a8'
GREEN     = '#4ade80'
RED       = '#f87171'
GOLD      = '#fbbf24'
PM_COLOR  = '#f472b6'
SERVER_COLOR = '#94a3b8'
FONT_MSG  = ('Segoe UI', 10)
FONT_UI   = ('Segoe UI', 10)
FONT_BOLD = ('Segoe UI', 10, 'bold')
FONT_H    = ('Segoe UI', 13, 'bold')
FONT_SMALL= ('Segoe UI', 8)


# ═══════════════════════════════════════════════════════════════════════════════
#  Login Window
# ═══════════════════════════════════════════════════════════════════════════════
class LoginWindow:
    def __init__(self, root, host, port):
        self.root = root
        self.host = host
        self.port = port
        self.result = None          # (username, socket) on success

        root.title("Chat – Connect")
        root.resizable(False, False)
        root.configure(bg=BG_DARK)
        self._center(380, 340)

        # ── Card frame ────────────────────────────────────────────────────────
        card = tk.Frame(root, bg=BG_MID, bd=0)
        card.pack(expand=True, fill='both', padx=30, pady=30)

        tk.Label(card, text="💬", font=('Segoe UI', 30),
                 bg=BG_MID, fg=ACCENT).pack(pady=(18, 4))
        tk.Label(card, text="TCP Chat", font=FONT_H,
                 bg=BG_MID, fg=TXT_WHITE).pack()
        tk.Label(card, text=f"Server  {host}:{port}", font=FONT_SMALL,
                 bg=BG_MID, fg=TXT_GREY).pack(pady=(2, 16))

        # Username
        tk.Label(card, text="Username", font=FONT_UI,
                 bg=BG_MID, fg=TXT_GREY, anchor='w').pack(fill='x', padx=24)
        self.user_var = tk.StringVar()
        self.user_entry = ttk.Entry(card, textvariable=self.user_var, font=FONT_UI)
        self.user_entry.pack(fill='x', padx=24, pady=(2, 10), ipady=5)

        # Password (optional / display-only)
        tk.Label(card, text="Password  (optional)", font=FONT_UI,
                 bg=BG_MID, fg=TXT_GREY, anchor='w').pack(fill='x', padx=24)
        self.pass_entry = ttk.Entry(card, show='•', font=FONT_UI)
        self.pass_entry.pack(fill='x', padx=24, pady=(2, 16), ipady=5)

        # Status label
        self.status_var = tk.StringVar(value="Enter your username to connect.")
        tk.Label(card, textvariable=self.status_var, font=FONT_SMALL,
                 bg=BG_MID, fg=TXT_GREY, wraplength=300).pack()

        # Connect button
        self.btn = tk.Button(card, text="Connect", font=FONT_BOLD,
                             bg=ACCENT, fg='white', activebackground='#6455d6',
                             activeforeground='white', relief='flat',
                             cursor='hand2', command=self._on_connect)
        self.btn.pack(fill='x', padx=24, pady=(10, 4), ipady=7)

        root.bind('<Return>', lambda e: self._on_connect())
        self.user_entry.focus_set()

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _center(self, w, h):
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

    def _set_status(self, msg, color=TXT_GREY):
        self.status_var.set(msg)
        for w in self.root.winfo_children():
            for ww in w.winfo_children():
                if isinstance(ww, tk.Label) and ww.cget('textvariable') == str(self.status_var):
                    ww.config(fg=color)

    def _on_connect(self):
        username = self.user_var.get().strip()
        if not username:
            messagebox.showerror("Validation Error", "Username cannot be empty.", parent=self.root)
            return
        if ' ' in username:
            messagebox.showerror("Validation Error", "Username must not contain spaces.", parent=self.root)
            return

        self.btn.config(state='disabled', text='Connecting…')
        self.status_var.set(f"Connecting to {self.host}:{self.port} …")
        self.root.update()

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((self.host, self.port))
            sock.settimeout(None)
            # consume server welcome prompt
            sock.recv(1024)   # WELCOME line
            sock.recv(1024)   # PROMPT line
            # send username
            sock.sendall((username + '\n').encode('utf-8'))
        except Exception as e:
            self.btn.config(state='normal', text='Connect')
            messagebox.showerror("Connection Failed", str(e), parent=self.root)
            return

        self.result = (username, sock)
        self.root.destroy()


# ═══════════════════════════════════════════════════════════════════════════════
#  Chat Window
# ═══════════════════════════════════════════════════════════════════════════════
class ChatWindow:
    def __init__(self, root, username, sock):
        self.root = root
        self.username = username
        self.sock = sock
        self.running = True

        root.title(f"TCP Chat  —  {username}")
        root.configure(bg=BG_DARK)
        root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._center(900, 620)

        self._build_ui()
        self._configure_tags()

        # Start background receive thread
        threading.Thread(target=self._recv_loop, daemon=True).start()
        self._set_status("Connected", GREEN)
        self._append(f"Connected as {username}. Type /help for commands.\n", 'server')

    # ── Layout ────────────────────────────────────────────────────────────────
    def _build_ui(self):
        root = self.root

        # ── Top bar ───────────────────────────────────────────────────────────
        topbar = tk.Frame(root, bg=BG_MID, height=48)
        topbar.pack(fill='x', side='top')
        topbar.pack_propagate(False)

        tk.Label(topbar, text="💬 TCP Chat", font=FONT_H,
                 bg=BG_MID, fg=TXT_WHITE).pack(side='left', padx=16, pady=8)
        tk.Label(topbar, text=f"Logged in as  {self.username}", font=FONT_UI,
                 bg=BG_MID, fg=TXT_GREY).pack(side='left', padx=8)

        self.status_dot = tk.Label(topbar, text="●", font=FONT_UI,
                                   bg=BG_MID, fg=GREEN)
        self.status_dot.pack(side='right', padx=4)
        self.status_lbl = tk.Label(topbar, text="Connecting…", font=FONT_SMALL,
                                   bg=BG_MID, fg=TXT_GREY)
        self.status_lbl.pack(side='right', padx=4)

        # ── Main body ─────────────────────────────────────────────────────────
        body = tk.Frame(root, bg=BG_DARK)
        body.pack(fill='both', expand=True)

        # Left: messages
        left = tk.Frame(body, bg=BG_DARK)
        left.pack(side='left', fill='both', expand=True)

        self.msg_area = scrolledtext.ScrolledText(
            left, state='disabled', wrap='word',
            bg=BG_DARK, fg=TXT_WHITE, font=FONT_MSG,
            insertbackground=TXT_WHITE, relief='flat',
            padx=12, pady=8, selectbackground=ACCENT,
        )
        self.msg_area.pack(fill='both', expand=True)

        # Right: online users panel
        right = tk.Frame(body, bg=BG_PANEL, width=180)
        right.pack(side='right', fill='y')
        right.pack_propagate(False)

        tk.Label(right, text="Online Users", font=FONT_BOLD,
                 bg=BG_PANEL, fg=TXT_WHITE).pack(pady=(14, 6), padx=10)

        sep = tk.Frame(right, bg=ACCENT, height=1)
        sep.pack(fill='x', padx=10)

        self.user_listbox = tk.Listbox(
            right, bg=BG_PANEL, fg=TXT_WHITE, font=FONT_UI,
            relief='flat', selectbackground=ACCENT,
            activestyle='none', highlightthickness=0, bd=0,
            cursor='hand2',
        )
        self.user_listbox.pack(fill='both', expand=True, padx=6, pady=6)
        self.user_listbox.bind('<Double-Button-1>', self._on_user_double_click)

        tk.Label(right, text="Double-click to PM", font=FONT_SMALL,
                 bg=BG_PANEL, fg=TXT_GREY).pack(pady=(0, 10))

        # ── Bottom bar ────────────────────────────────────────────────────────
        bottom = tk.Frame(root, bg=BG_MID, height=56)
        bottom.pack(fill='x', side='bottom')
        bottom.pack_propagate(False)

        self.pm_var = tk.StringVar()
        self.pm_target_lbl = tk.Label(bottom, text="", font=FONT_SMALL,
                                      bg=BG_MID, fg=PM_COLOR)
        self.pm_target_lbl.pack(side='left', padx=(10, 0))

        self.msg_var = tk.StringVar()
        self.msg_entry = ttk.Entry(bottom, textvariable=self.msg_var, font=FONT_MSG)
        self.msg_entry.pack(side='left', fill='x', expand=True,
                            padx=(8, 6), pady=10, ipady=5)
        self.msg_entry.bind('<Return>', lambda e: self._send_message())

        tk.Button(bottom, text="Send", font=FONT_BOLD, bg=ACCENT2, fg='white',
                  activebackground='#4a7bcb', relief='flat', cursor='hand2',
                  command=self._send_message, padx=14).pack(side='left', pady=10)

        tk.Button(bottom, text="Disconnect", font=FONT_UI, bg=RED, fg='white',
                  activebackground='#d95f5f', relief='flat', cursor='hand2',
                  command=self._on_close, padx=10).pack(side='left', padx=(6, 10), pady=10)

        self.msg_entry.focus_set()

    def _configure_tags(self):
        ma = self.msg_area
        ma.tag_config('server',    foreground=SERVER_COLOR, font=('Segoe UI', 9, 'italic'))
        ma.tag_config('broadcast', foreground=TXT_WHITE,    font=FONT_MSG)
        ma.tag_config('self',      foreground=ACCENT2,      font=FONT_BOLD)
        ma.tag_config('pm',        foreground=PM_COLOR,     font=FONT_BOLD)
        ma.tag_config('history',   foreground=TXT_GREY,     font=('Segoe UI', 9, 'italic'))
        ma.tag_config('error',     foreground=RED,          font=FONT_MSG)
        ma.tag_config('ts',        foreground=TXT_GREY,     font=FONT_SMALL)

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _center(self, w, h):
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

    def _set_status(self, text, color=TXT_GREY):
        self.status_lbl.config(text=text, fg=color)
        self.status_dot.config(fg=color)

    def _append(self, text, tag='broadcast'):
        self.msg_area.config(state='normal')
        ts = datetime.now().strftime('%H:%M')
        self.msg_area.insert('end', f"[{ts}] ", 'ts')
        self.msg_area.insert('end', text + '\n', tag)
        self.msg_area.config(state='disabled')
        self.msg_area.see('end')

    def _update_user_list(self, users):
        self.user_listbox.delete(0, 'end')
        for u in users:
            if u and u != self.username:
                self.user_listbox.insert('end', f"  {u}")
            elif u == self.username:
                self.user_listbox.insert('end', f"  {u}  (you)")

    # ── PM shortcut via double-click ──────────────────────────────────────────
    def _on_user_double_click(self, event):
        sel = self.user_listbox.curselection()
        if not sel:
            return
        raw = self.user_listbox.get(sel[0]).strip()
        target = raw.replace('  (you)', '').strip()
        if target == self.username:
            return
        current = self.msg_var.get()
        if not current.startswith(f'/msg {target} '):
            self.msg_var.set(f'/msg {target} ')
        self.pm_target_lbl.config(text=f"PM → {target}")
        self.msg_entry.focus_set()
        self.msg_entry.icursor('end')

    # ── Send ──────────────────────────────────────────────────────────────────
    def _send_message(self):
        text = self.msg_var.get().strip()
        if not text:
            return
        try:
            self.sock.sendall((text + '\n').encode('utf-8'))
        except Exception as e:
            self._append(f"[ERROR] Could not send: {e}", 'error')
            return
        self.msg_var.set('')
        if text.startswith('/msg '):
            self.pm_target_lbl.config(text="")

    # ── Receive loop (background thread) ──────────────────────────────────────
    def _recv_loop(self):
        buf = ''
        while self.running:
            try:
                data = self.sock.recv(4096)
                if not data:
                    self.root.after(0, self._handle_disconnect)
                    break
                buf += data.decode('utf-8')
                while '\n' in buf:
                    line, buf = buf.split('\n', 1)
                    line = line.strip()
                    if line:
                        self.root.after(0, self._process_line, line)
            except OSError:
                break
            except Exception as e:
                if self.running:
                    self.root.after(0, self._append, f"[!] Receive error: {e}", 'error')
                break

    def _process_line(self, line):
        """Called on main thread via root.after()."""
        if line.startswith('USERLIST:'):
            users = line[9:].split(',')
            self._update_user_list([u.strip() for u in users if u.strip()])
        elif line.startswith('PM:'):
            self._append(line[3:], 'pm')
        elif line.startswith('YOU:'):
            self._append(line[4:], 'self')
        elif line.startswith('SERVER:'):
            text = line[7:]
            tag = 'error' if text.startswith('[ERROR]') else 'server'
            self._append(text, tag)
        elif line.startswith('HISTORY:'):
            self._append(line[8:], 'history')
        elif line.startswith('WELCOME:') or line.startswith('PROMPT:'):
            pass  # consumed during login
        elif line.startswith('[SERVER]'):
            self._append(line, 'server')
        else:
            self._append(line, 'broadcast')

    def _handle_disconnect(self):
        self.running = False
        self._set_status("Disconnected", RED)
        self._append("[SERVER] Connection closed by server.", 'server')
        messagebox.showinfo("Disconnected", "The server closed the connection.", parent=self.root)

    # ── Close ─────────────────────────────────────────────────────────────────
    def _on_close(self):
        if self.running:
            self.running = False
            try:
                self.sock.sendall('/quit\n'.encode('utf-8'))
            except Exception:
                pass
            try:
                self.sock.close()
            except Exception:
                pass
        self._set_status("Disconnected", RED)
        self.root.destroy()


# ═══════════════════════════════════════════════════════════════════════════════
#  Entry point
# ═══════════════════════════════════════════════════════════════════════════════
def main():
    host = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_HOST
    port = int(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_PORT

    # ── Login ─────────────────────────────────────────────────────────────────
    login_root = tk.Tk()
    _apply_ttk_style(login_root)
    login = LoginWindow(login_root, host, port)
    login_root.mainloop()

    if login.result is None:
        return          # user closed the window without connecting

    username, sock = login.result

    # ── Chat ──────────────────────────────────────────────────────────────────
    chat_root = tk.Tk()
    _apply_ttk_style(chat_root)
    ChatWindow(chat_root, username, sock)
    chat_root.mainloop()


def _apply_ttk_style(root):
    style = ttk.Style(root)
    try:
        style.theme_use('clam')
    except Exception:
        pass
    style.configure('TEntry',
                    fieldbackground='#2e2e45',
                    foreground=TXT_WHITE,
                    insertcolor=TXT_WHITE,
                    bordercolor='#44445a',
                    lightcolor='#44445a',
                    darkcolor='#44445a',
                    padding=4)
    style.map('TEntry', bordercolor=[('focus', ACCENT)])


if __name__ == '__main__':
    main()
