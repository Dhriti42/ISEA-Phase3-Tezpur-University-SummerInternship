"""
Assignment 6: GUI-Based Multi-Client Chat Application Using TCP
server.py  — Reused from Assignment 5 with minimal modifications.
Run on h1 (10.0.0.1) inside Mininet.
"""

import socket
import threading
import csv
import os
from datetime import datetime

# ─── Configuration ────────────────────────────────────────────────────────────
HOST = '0.0.0.0'
PORT = 5000
HISTORY_FILE = 'chat_history.csv'
HISTORY_FIELDS = ['timestamp', 'sender', 'receiver', 'message_type', 'message']
HISTORY_TAIL = 5

# ─── Shared State ─────────────────────────────────────────────────────────────
clients_lock = threading.Lock()
clients = {}        # username -> {socket, address, port, login_time, status}
stats_lock = threading.Lock()
stats = {
    'connected': 0,
    'messages_processed': 0,
    'broadcast_messages': 0,
    'private_messages': 0,
}


# ─── CSV helpers ──────────────────────────────────────────────────────────────
def init_history_file():
    if not os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, 'w', newline='') as f:
            csv.DictWriter(f, fieldnames=HISTORY_FIELDS).writeheader()


def log_message(sender, receiver, msg_type, message):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(HISTORY_FILE, 'a', newline='') as f:
        csv.DictWriter(f, fieldnames=HISTORY_FIELDS).writerow({
            'timestamp': ts, 'sender': sender, 'receiver': receiver,
            'message_type': msg_type, 'message': message,
        })


def get_last_messages(username, n=HISTORY_TAIL):
    rows = []
    try:
        with open(HISTORY_FILE, newline='') as f:
            for row in csv.DictReader(f):
                if row['sender'] == username:
                    rows.append(row)
    except FileNotFoundError:
        pass
    return rows[-n:]


# ─── Sending / broadcasting ───────────────────────────────────────────────────
def send_to(sock, message):
    try:
        sock.sendall((message + '\n').encode('utf-8'))
    except Exception:
        pass


def broadcast(message, exclude=None, msg_type='broadcast', sender='SERVER'):
    with clients_lock:
        targets = list(clients.items())
    for uname, info in targets:
        if uname != exclude:
            send_to(info['socket'], message)
    if msg_type == 'broadcast':
        log_message(sender, 'ALL', 'broadcast', message)
        with stats_lock:
            stats['broadcast_messages'] += 1
            stats['messages_processed'] += 1


def online_list_str():
    with clients_lock:
        return ', '.join(u for u, i in clients.items() if i['status'] == 'online') or 'none'


def server_stats_str():
    with stats_lock:
        s = stats.copy()
    lines = [
        "─── Server Statistics ───────────────────────────────",
        f"  Connected users     : {s['connected']}",
        f"  Online now          : {online_list_str()}",
        f"  Messages processed  : {s['messages_processed']}",
        f"  Broadcast messages  : {s['broadcast_messages']}",
        f"  Private messages    : {s['private_messages']}",
        "─────────────────────────────────────────────────────",
    ]
    return '\n'.join(lines)


# ─── Client handler ───────────────────────────────────────────────────────────
def handle_client(conn, addr):
    ip, port = addr
    username = None
    try:
        send_to(conn, "WELCOME:Welcome to the Advanced TCP Chat Server!")
        send_to(conn, "PROMPT:Enter your username: ")
        raw = conn.recv(1024).decode('utf-8').strip()
        if not raw:
            conn.close()
            return
        username = raw
        login_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        with clients_lock:
            returning = username in clients
            clients[username] = {
                'socket': conn, 'address': ip, 'port': port,
                'login_time': login_time, 'status': 'online',
            }
        with stats_lock:
            stats['connected'] += 1

        print(f"[+] {username} connected from {ip}:{port}")

        # Reconnect history
        if returning:
            history = get_last_messages(username)
            if history:
                send_to(conn, f"HISTORY:── Your last {len(history)} messages ──────────────────")
                for row in history:
                    send_to(conn, f"HISTORY:  [{row['timestamp']}] → {row['receiver']}: {row['message']}")

        # Announce join and push updated user list
        join_msg = f"[SERVER] {username} has joined the chat from {ip}:{port}."
        broadcast(join_msg, exclude=username, msg_type='server', sender='SERVER')
        send_to(conn, f"SERVER:Welcome, {username}! Type /help for commands.")
        log_message('SERVER', username, 'system', join_msg)

        # Push online list to ALL clients
        _push_user_list()
        print(server_stats_str())

        # Main loop
        while True:
            data = conn.recv(4096)
            if not data:
                break
            message = data.decode('utf-8').strip()
            if not message:
                continue
            print(f"[{username}] {message}")

            if message.lower() in ('/quit', '/exit', '/bye'):
                send_to(conn, "SERVER:Goodbye!")
                break

            elif message.lower() == '/help':
                help_text = (
                    "── Commands ─────────────────────────────────────────\n"
                    "  /msg <username> <text>  – Send a private message\n"
                    "  /list                   – Show online users\n"
                    "  /stats                  – Show server statistics\n"
                    "  /quit                   – Disconnect\n"
                    "─────────────────────────────────────────────────────"
                )
                send_to(conn, f"SERVER:{help_text}")

            elif message.lower() == '/list':
                with clients_lock:
                    online = [
                        f"  • {u}  ({i['address']}:{i['port']})  since {i['login_time']}"
                        for u, i in clients.items() if i['status'] == 'online'
                    ]
                listing = "── Online Users ─────────────────────────────────────\n"
                listing += '\n'.join(online) if online else "  (none)"
                listing += "\n─────────────────────────────────────────────────────"
                send_to(conn, f"SERVER:{listing}")

            elif message.lower() == '/stats':
                send_to(conn, f"SERVER:{server_stats_str()}")

            elif message.startswith('/msg '):
                parts = message.split(' ', 2)
                if len(parts) < 3:
                    send_to(conn, "SERVER:[ERROR] Usage: /msg <username> <message>")
                    continue
                _, target, text = parts
                if target == username:
                    send_to(conn, "SERVER:[ERROR] You cannot message yourself.")
                    continue
                with clients_lock:
                    target_info = clients.get(target)
                    target_online = target_info and target_info['status'] == 'online'
                if not target_info:
                    send_to(conn, f"SERVER:[ERROR] User '{target}' does not exist.")
                elif not target_online:
                    send_to(conn, f"SERVER:[ERROR] User '{target}' is currently offline.")
                else:
                    send_to(target_info['socket'], f"PM:[PM from {username}] {text}")
                    send_to(conn, f"PM:[PM to {target}] {text}")
                    log_message(username, target, 'private', text)
                    with stats_lock:
                        stats['private_messages'] += 1
                        stats['messages_processed'] += 1

            else:
                bcast = f"[{username}] {message}"
                broadcast(bcast, exclude=username, msg_type='broadcast', sender=username)
                send_to(conn, f"YOU:[You] {message}")
                log_message(username, 'ALL', 'broadcast', message)
                with stats_lock:
                    stats['messages_processed'] += 1

    except Exception as e:
        print(f"[!] Error with {username or addr}: {e}")
    finally:
        if username:
            with clients_lock:
                if username in clients:
                    clients[username]['status'] = 'offline'
            with stats_lock:
                stats['connected'] = max(0, stats['connected'] - 1)
            leave_msg = f"[SERVER] {username} has left the chat."
            broadcast(leave_msg, exclude=username, msg_type='server', sender='SERVER')
            log_message('SERVER', username, 'system', leave_msg)
            _push_user_list()
            print(f"[-] {username} disconnected.")
            print(server_stats_str())
        try:
            conn.close()
        except Exception:
            pass


def _push_user_list():
    """Push a USERLIST frame to every online client so GUIs can refresh instantly."""
    with clients_lock:
        online = [u for u, i in clients.items() if i['status'] == 'online']
        targets = list(clients.items())
    user_str = ','.join(online)
    for _, info in targets:
        send_to(info['socket'], f"USERLIST:{user_str}")


# ─── Main ─────────────────────────────────────────────────────────────────────
def main():
    init_history_file()
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(10)
    print(f"[*] Chat Server listening on {HOST}:{PORT}")
    print("[*] Press Ctrl+C to stop.\n")
    try:
        while True:
            conn, addr = server.accept()
            threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()
    except KeyboardInterrupt:
        print("\n[*] Server shutting down.")
    finally:
        server.close()


if __name__ == '__main__':
    main()
