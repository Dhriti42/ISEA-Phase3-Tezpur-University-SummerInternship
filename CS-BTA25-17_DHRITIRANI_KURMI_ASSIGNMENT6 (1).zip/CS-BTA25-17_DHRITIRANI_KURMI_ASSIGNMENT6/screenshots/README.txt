Place the following Wireshark / application screenshots here before submission:

Application Screenshots (required):
- login_window.png            — Login window showing username/password fields
- successful_connection.png   — Status bar showing "Connected" after login
- main_chat_window.png        — Full chat window with message area and user panel
- broadcast_messaging.png     — A broadcast message visible to multiple clients
- private_messaging.png       — Private message sent via /msg or double-click PM
- user_joining.png            — "[SERVER] <user> has joined" notification in chat
- user_leaving.png            — "[SERVER] <user> has left" notification in chat

Wireshark Screenshots (required, filter: tcp.port == 5000):
- wireshark_client_connection.png   — TCP 3-way handshake (SYN / SYN-ACK / ACK)
- wireshark_broadcast_message.png   — PSH+ACK from client -> server -> all clients
- wireshark_private_message.png     — PSH+ACK from server -> single recipient only
- wireshark_client_disconnect.png   — FIN+ACK teardown sequence

Capture command (inside Mininet xterm):
    wireshark -i <interface> -f "tcp.port == 5000" &
