"""
Assignment 5: Advanced Multi-Client Chat Server using TCP
client.py - TCP Chat Client
"""

import socket
import threading
import sys
import time

# ─── Configuration ────────────────────────────────────────────────────────────
DEFAULT_HOST = '10.0.0.1'   # h1 in Mininet topology
DEFAULT_PORT = 5000

# ─── Globals ──────────────────────────────────────────────────────────────────
running = True


# ─── Receive thread ───────────────────────────────────────────────────────────
def receive_messages(sock):
    global running
    while running:
        try:
            data = sock.recv(4096)
            if not data:
                print("\n[SERVER] Connection closed by server.")
                running = False
                break
            messages = data.decode('utf-8').strip().split('\n')
            for msg in messages:
                if msg:
                    print(f"\r{msg}\n> ", end='', flush=True)
        except OSError:
            break
        except Exception as e:
            if running:
                print(f"\n[!] Receive error: {e}")
            break
    running = False


# ─── Main ─────────────────────────────────────────────────────────────────────
def main():
    global running

    # Parse arguments: python client.py [host] [port]
    host = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_HOST
    port = int(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_PORT

    print(f"[*] Connecting to {host}:{port} ...")
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((host, port))
    except ConnectionRefusedError:
        print(f"[!] Could not connect to {host}:{port}. Is the server running?")
        sys.exit(1)
    except Exception as e:
        print(f"[!] Connection error: {e}")
        sys.exit(1)

    print(f"[*] Connected to {host}:{port}")

    # Start background receive thread
    recv_thread = threading.Thread(target=receive_messages, args=(sock,), daemon=True)
    recv_thread.start()

    try:
        while running:
            try:
                user_input = input('> ')
            except EOFError:
                break
            if not running:
                break
            if not user_input.strip():
                continue
            try:
                sock.sendall((user_input.strip() + '\n').encode('utf-8'))
            except Exception as e:
                print(f"[!] Send error: {e}")
                break
            if user_input.strip().lower() in ('/quit', '/exit', '/bye'):
                running = False
                break
            # Small delay so server reply can interleave nicely in the terminal
            time.sleep(0.05)
    except KeyboardInterrupt:
        print("\n[*] Disconnecting...")
    finally:
        running = False
        try:
            sock.sendall('/quit\n'.encode('utf-8'))
        except Exception:
            pass
        sock.close()
        print("[*] Disconnected.")


if __name__ == '__main__':
    main()
