Place Wireshark screenshots here:
- client_connection.png        (TCP 3-way handshake with h2)
- broadcast_message.png        (PSH+ACK to all clients)
- private_message.png          (PSH+ACK to single recipient)
- client_disconnect.png        (FIN+ACK teardown)
- tcp_termination.png          (TIME_WAIT state)

Capture using: wireshark -i <interface> -f 'tcp.port == 5000'
