# Assignment 4 – Multi-Client Chat Server using TCP

Rename this folder to `ROLLNO_NAME_CHATSERVER` (replace with your actual roll
number and name) before zipping for submission.

## Files
- `server.py` – multi-threaded TCP chat server (Task 1 & 2)
- `client.py` – TCP chat client with username registration (Task 2)
- `performance_test.py` – automated load test for 1/2/3 clients × 20 msgs (Task 3)
- `generate_graphs.py` – builds the two required graphs from the CSV (Task 5)
- `reflection_answers.txt` – draft answers for Task 6 (paste into report.pdf)
- `chat_log.txt`, `server_log.csv`, `performance_results.csv` – generated at runtime
- `graphs/` – output folder for the two PNG graphs
- `screenshots/` – put your four Wireshark screenshots here

## 1. Mininet setup
```
sudo mn --topo single,4
nodes
net
pingall
```
Topology: h1 = server, h2/h3/h4 = clients A/B/C.

## 2. Run the server (on h1)
```
h1 python3 server.py
```
This listens on port 5000 and writes `server_log.csv` (CONNECTED/DISCONNECTED
events) and `chat_log.txt` (all chat messages) in the working directory.

## 3. Run clients (on h2, h3, h4)
```
h2 python3 client.py 10.0.0.1
h3 python3 client.py 10.0.0.1
h4 python3 client.py 10.0.0.1
```
Enter a username when prompted, then type messages. Type `/QUIT` to leave.

## 4. Performance measurement (Task 3)
With the server running, from a client host run each scenario separately
(clear or rename `performance_results.csv` between full test runs if you
want a fresh file):
```
h2 python3 performance_test.py 10.0.0.1 1
h2 python3 performance_test.py 10.0.0.1 2
h2 python3 performance_test.py 10.0.0.1 3
```
The script spins up N synthetic clients, has each send 20 timestamped
messages, listens on a dedicated monitor connection for the broadcasts, and
appends one row per run to `performance_results.csv`:
```
clients,total_messages,avg_delivery_time_ms,throughput_msgs_per_sec
```

## 5. Wireshark capture (Task 4)
While clients are connecting/chatting, capture with filter:
```
tcp.port == 5000
```
Save these into `screenshots/`:
- `tcp_handshake.png` – SYN / SYN-ACK / ACK
- `chat_message.png` – a client → server chat packet
- `broadcast_message.png` – a server → client broadcast packet
- `connection_close.png` – FIN/ACK termination

## 6. Graph generation (Task 5)
After `performance_results.csv` has rows for 1, 2, and 3 clients:
```
pip install matplotlib --break-system-packages   # if not already installed
python3 generate_graphs.py
```
This writes `graphs/clients_vs_delay.png` and `graphs/clients_vs_throughput.png`.

## 7. Report
Compile `report.pdf` using the structure required by the assignment
(Objective, Topology, Design, Results, Wireshark, Graphs, Reflection,
Conclusion), pulling in your logs, CSV, screenshots, and graphs, plus the
answers from `reflection_answers.txt`.

## Notes
- `performance_test.py` and `generate_graphs.py` are test-automation helpers
  you write/run yourself for the assignment — read through them and adjust
  the pacing delay or message count if your instructor requires different
  parameters.
- Everything must actually be executed inside Mininet with real Wireshark
  captures; the generated CSV/log files here are placeholders until you run
  the real experiment.
