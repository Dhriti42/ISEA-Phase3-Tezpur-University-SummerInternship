"""
client.py - Chat Client using TCP
Assignment 4 - Task 1 & Task 2

Usage:
    python3 client.py <server_ip> [port]

Default port: 5000
Type /QUIT to exit.
"""

import socket
import threading
import sys

PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 5000
SERVER_IP = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"


def receive_messages(sock):
    while True:
        try:
            data = sock.recv(1024)
            if not data:
                print("[DISCONNECTED] Server closed the connection.")
                break
            print(data.decode("utf-8"), end="")
        except Exception:
            break


def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((SERVER_IP, PORT))

    # Handle "Enter Username:" prompt from server
    prompt = sock.recv(1024).decode("utf-8")
    username = input(prompt)
    sock.sendall(username.encode("utf-8"))

    recv_thread = threading.Thread(target=receive_messages, args=(sock,), daemon=True)
    recv_thread.start()

    print("Connected. Type your messages below (/QUIT to exit).")
    try:
        while True:
            message = input()
            if message.strip() == "":
                continue
            sock.sendall(message.encode("utf-8"))
            if message.upper() == "/QUIT":
                break
    except (KeyboardInterrupt, EOFError):
        sock.sendall("/QUIT".encode("utf-8"))
    finally:
        sock.close()


if __name__ == "__main__":
    main()
