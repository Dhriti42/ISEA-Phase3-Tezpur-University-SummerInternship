"""
server.py - Multi-Client Chat Server using TCP
Assignment 4 - Task 1 & Task 2

Usage:
    python3 server.py [port]

Default port: 5000
"""

import socket
import threading
import sys
import datetime
import csv
import os

HOST = "0.0.0.0"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 5000

SERVER_LOG_FILE = "server_log.csv"
CHAT_LOG_FILE = "chat_log.txt"

# Shared state
clients_lock = threading.Lock()
clients = {}   # conn -> {"username": str, "ip": str}


def timestamp():
    return datetime.datetime.now().strftime("%H:%M:%S")


def full_timestamp():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log_server_event(event, username, ip):
    """timestamp,EVENT,username,client_ip"""
    file_exists = os.path.isfile(SERVER_LOG_FILE)
    with open(SERVER_LOG_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([timestamp(), event, username, ip])
    print(f"[LOG] {timestamp()},{event},{username},{ip}")


def log_chat_message(username, message):
    """timestamp,username,message"""
    with open(CHAT_LOG_FILE, "a") as f:
        f.write(f"{full_timestamp()},{username},{message}\n")


def broadcast(message, sender_conn=None):
    """Send message to all connected clients (optionally excluding sender)."""
    with clients_lock:
        dead_conns = []
        for conn in clients:
            try:
                conn.sendall(message.encode("utf-8"))
            except Exception:
                dead_conns.append(conn)
        for conn in dead_conns:
            clients.pop(conn, None)


def handle_client(conn, addr):
    ip = addr[0]
    username = None
    try:
        # Registration step
        conn.sendall("Enter Username: ".encode("utf-8"))
        data = conn.recv(1024)
        if not data:
            return
        username = data.decode("utf-8").strip()

        with clients_lock:
            clients[conn] = {"username": username, "ip": ip}

        log_server_event("CONNECTED", username, ip)
        broadcast(f"** {username} has joined the chat **\n", conn)

        while True:
            data = conn.recv(1024)
            if not data:
                break
            message = data.decode("utf-8").strip()
            if message == "":
                continue
            if message.upper() == "/QUIT":
                break

            log_chat_message(username, message)
            broadcast(f"[{username}] {message}\n")

    except ConnectionResetError:
        pass
    finally:
        with clients_lock:
            clients.pop(conn, None)
        if username:
            log_server_event("DISCONNECTED", username, ip)
            broadcast(f"** {username} has left the chat **\n")
        conn.close()


def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(10)
    print(f"[STARTED] Chat server listening on {HOST}:{PORT}")

    try:
        while True:
            conn, addr = server_socket.accept()
            thread = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
            thread.start()
            with clients_lock:
                active = len(clients) + 1
            print(f"[ACTIVE CONNECTIONS] {threading.active_count() - 1}")
    except KeyboardInterrupt:
        print("\n[SHUTTING DOWN] Server closing...")
    finally:
        server_socket.close()


if __name__ == "__main__":
    main()
