"""
performance_test.py - Task 3: Performance Measurement

Runs automated experiments with 1, 2, and 3 clients (each sending 20 messages)
against a running server.py instance, and records:
    - total_messages
    - avg_delivery_time_ms
    - throughput_msgs_per_sec

Run this AFTER starting server.py (on h1) and BEFORE starting manual clients.
On Mininet, run separately for each experiment, e.g.:
    h1 python3 server.py
    h2 python3 performance_test.py 10.0.0.1 1     # 1 client
    h2 python3 performance_test.py 10.0.0.1 2     # 2 clients
    h2 python3 performance_test.py 10.0.0.1 3     # 3 clients

Usage:
    python3 performance_test.py <server_ip> <num_clients> [port]
"""

import socket
import threading
import time
import sys
import csv
import os

SERVER_IP = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
NUM_CLIENTS = int(sys.argv[2]) if len(sys.argv) > 2 else 1
PORT = int(sys.argv[3]) if len(sys.argv) > 3 else 5000
MESSAGES_PER_CLIENT = 20
RESULTS_FILE = "performance_results.csv"

latencies = []
latencies_lock = threading.Lock()


def monitor_thread(sock, expected_count, stop_event):
    """Listens on a dedicated monitoring connection and records latency
    for every broadcast message that carries a send-timestamp tag."""
    buffer = ""
    received = 0
    sock.settimeout(15)
    while received < expected_count and not stop_event.is_set():
        try:
            data = sock.recv(4096)
        except socket.timeout:
            break
        if not data:
            break
        buffer += data.decode("utf-8", errors="ignore")
        while "\n" in buffer:
            line, buffer = buffer.split("\n", 1)
            if "#T#" in line:
                try:
                    send_time = float(line.split("#T#")[1].strip())
                    recv_time = time.time()
                    with latencies_lock:
                        latencies.append((recv_time - send_time) * 1000.0)
                    received += 1
                except (IndexError, ValueError):
                    pass
    stop_event.set()


def register(sock, username):
    sock.recv(1024)  # "Enter Username:" prompt
    sock.sendall(username.encode("utf-8"))
    time.sleep(0.1)


def client_worker(client_id, barrier):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((SERVER_IP, PORT))
    username = f"perf_client_{client_id}"
    register(sock, username)

    # drain the join notifications briefly
    sock.settimeout(0.5)
    try:
        while True:
            if not sock.recv(4096):
                break
    except socket.timeout:
        pass
    sock.settimeout(None)

    barrier.wait()  # synchronize start across clients

    for i in range(MESSAGES_PER_CLIENT):
        send_time = time.time()
        msg = f"perf message {i} #T#{send_time}"
        sock.sendall(msg.encode("utf-8"))
        time.sleep(0.05)  # small pacing delay

    time.sleep(1.0)  # allow final broadcasts to arrive
    sock.sendall("/QUIT".encode("utf-8"))
    sock.close()


def main():
    total_expected = NUM_CLIENTS * MESSAGES_PER_CLIENT

    # Dedicated monitor connection that just listens to all broadcasts
    monitor_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    monitor_sock.connect((SERVER_IP, PORT))
    register(monitor_sock, "perf_monitor")

    stop_event = threading.Event()
    mon_thread = threading.Thread(
        target=monitor_thread, args=(monitor_sock, total_expected, stop_event)
    )
    mon_thread.start()

    barrier = threading.Barrier(NUM_CLIENTS)
    start_time = time.time()

    workers = []
    for cid in range(NUM_CLIENTS):
        t = threading.Thread(target=client_worker, args=(cid, barrier))
        workers.append(t)
        t.start()

    for t in workers:
        t.join()

    mon_thread.join(timeout=20)
    stop_event.set()
    end_time = time.time()

    try:
        monitor_sock.close()
    except Exception:
        pass

    with latencies_lock:
        total_delivered = len(latencies)
        avg_latency_ms = (sum(latencies) / total_delivered) if total_delivered else 0.0

    elapsed = max(end_time - start_time, 0.0001)
    throughput = total_delivered / elapsed

    print(f"Clients: {NUM_CLIENTS}")
    print(f"Total messages delivered (observed): {total_delivered}")
    print(f"Average delivery time: {avg_latency_ms:.2f} ms")
    print(f"Throughput: {throughput:.2f} msgs/sec")

    file_exists = os.path.isfile(RESULTS_FILE)
    with open(RESULTS_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(
                ["clients", "total_messages", "avg_delivery_time_ms", "throughput_msgs_per_sec"]
            )
        writer.writerow([NUM_CLIENTS, total_delivered, f"{avg_latency_ms:.2f}", f"{throughput:.2f}"])


if __name__ == "__main__":
    main()
