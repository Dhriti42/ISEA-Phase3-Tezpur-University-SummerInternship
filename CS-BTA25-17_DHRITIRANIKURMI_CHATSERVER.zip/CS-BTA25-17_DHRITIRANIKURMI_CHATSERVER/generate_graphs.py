"""
generate_graphs.py - Task 5: Graph Generation

Reads performance_results.csv (produced by performance_test.py) and generates:
    graphs/clients_vs_delay.png
    graphs/clients_vs_throughput.png

Usage:
    python3 generate_graphs.py
"""

import csv
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RESULTS_FILE = "performance_results.csv"
OUTPUT_DIR = "graphs"


def load_results():
    rows = []
    with open(RESULTS_FILE, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
    # If the same client-count was run multiple times, average the values
    grouped = {}
    for row in rows:
        c = int(row["clients"])
        grouped.setdefault(c, []).append(row)

    clients_sorted = sorted(grouped.keys())
    avg_delay = []
    throughput = []
    for c in clients_sorted:
        entries = grouped[c]
        avg_delay.append(sum(float(e["avg_delivery_time_ms"]) for e in entries) / len(entries))
        throughput.append(sum(float(e["throughput_msgs_per_sec"]) for e in entries) / len(entries))
    return clients_sorted, avg_delay, throughput


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    clients, avg_delay, throughput = load_results()

    # Graph 1: Clients vs Average Delivery Time
    plt.figure(figsize=(6, 4))
    plt.plot(clients, avg_delay, marker="o", color="#2563eb")
    plt.title("Number of Clients vs Average Delivery Time")
    plt.xlabel("Number of Clients")
    plt.ylabel("Average Delivery Time (ms)")
    plt.xticks(clients)
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "clients_vs_delay.png"), dpi=150)
    plt.close()

    # Graph 2: Clients vs Throughput
    plt.figure(figsize=(6, 4))
    plt.plot(clients, throughput, marker="s", color="#16a34a")
    plt.title("Number of Clients vs Throughput")
    plt.xlabel("Number of Clients")
    plt.ylabel("Throughput (msgs/sec)")
    plt.xticks(clients)
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "clients_vs_throughput.png"), dpi=150)
    plt.close()

    print("Graphs saved to graphs/clients_vs_delay.png and graphs/clients_vs_throughput.png")


if __name__ == "__main__":
    main()
