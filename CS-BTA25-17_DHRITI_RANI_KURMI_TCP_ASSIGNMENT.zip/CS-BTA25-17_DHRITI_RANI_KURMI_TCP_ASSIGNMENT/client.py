"""
TCP Connection Performance Analysis - CLIENT (h2)
Roll No: CS-BTA25-17
Name: Dhriti Rani Kurmi

Run this on h2 inside Mininet AFTER starting server.py on h1:
    h2 python3 client.py

It automatically runs BOTH modes (persistent, new_connection) across all
three message sizes (128, 512, 1024 bytes), 10 messages each
(2 x 3 x 10 = 60 messages total), and writes:

    result_table.csv           (6 rows: 2 modes x 3 sizes)
    message_response_log.csv   (60 rows: every individual message)

Wire format sent to server (one line per message, '\n' terminated):
    MSG_ID|MESSAGE_SIZE|MODE|MESSAGE_DATA

Server replies with:
    ACK|MSG_ID|RECEIVED_SIZE
"""

import socket
import time
import csv
import os

SERVER_IP = "10.0.0.1"
SERVER_PORT = 5000

MESSAGE_SIZES = [128, 512, 1024]
MODES = ["persistent", "new_connection"]
MESSAGES_PER_SIZE = 10

ROLL_NO = "CS-BTA25-17"
NAME = "Dhriti Rani Kurmi"
BANDWIDTH_MBPS = 5
DELAY_MS = 50


def make_payload(size):
    """Return a payload string of exactly `size` bytes (padded with 'A')."""
    return ("A" * size)


def recv_ack(sock):
    buf = b""
    while b"\n" not in buf:
        chunk = sock.recv(4096)
        if not chunk:
            return None
        buf += chunk
    line, _, _ = buf.partition(b"\n")
    return line.decode()


def send_one_message(sock, msg_id, size, mode):
    data = make_payload(size)
    packet = f"{msg_id}|{size}|{mode}|{data}\n"

    start = time.time()
    sock.sendall(packet.encode())
    ack = recv_ack(sock)
    end = time.time()

    if ack is None or not ack.startswith("ACK"):
        raise RuntimeError(f"Bad/absent ACK for msg_id={msg_id}: {ack}")

    response_time = end - start
    return response_time, len(packet.encode())


def run_persistent(size):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((SERVER_IP, SERVER_PORT))

    response_times = []
    total_bytes = 0
    start_all = time.time()

    for msg_id in range(1, MESSAGES_PER_SIZE + 1):
        rt, nbytes = send_one_message(sock, msg_id, size, "persistent")
        response_times.append(rt)
        total_bytes += nbytes
        print(f"[CLIENT][persistent][size={size}] msg_id={msg_id} response_time={rt:.4f}s")

    end_all = time.time()
    sock.close()

    total_time = end_all - start_all
    return response_times, total_bytes, total_time


def run_new_connection(size):
    response_times = []
    total_bytes = 0
    start_all = time.time()

    for msg_id in range(1, MESSAGES_PER_SIZE + 1):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((SERVER_IP, SERVER_PORT))
        rt, nbytes = send_one_message(sock, msg_id, size, "new_connection")
        response_times.append(rt)
        total_bytes += nbytes
        sock.close()
        print(f"[CLIENT][new_connection][size={size}] msg_id={msg_id} response_time={rt:.4f}s")

    end_all = time.time()
    total_time = end_all - start_all
    return response_times, total_bytes, total_time


def main():
    result_rows = []
    message_rows = []

    for mode in MODES:
        for size in MESSAGE_SIZES:
            if mode == "persistent":
                response_times, total_bytes, total_time = run_persistent(size)
            else:
                response_times, total_bytes, total_time = run_new_connection(size)

            avg_response_time = sum(response_times) / len(response_times)
            throughput = total_bytes / total_time if total_time > 0 else 0

            result_rows.append([
                ROLL_NO, NAME, mode, BANDWIDTH_MBPS, DELAY_MS, size,
                MESSAGES_PER_SIZE, round(avg_response_time, 6),
                round(throughput, 2), "SUCCESS"
            ])

            for i, rt in enumerate(response_times, start=1):
                message_rows.append([
                    ROLL_NO, NAME, mode, size, i, round(rt, 6)
                ])

            print(f"[CLIENT] mode={mode} size={size} "
                  f"avg_response_time={avg_response_time:.4f}s throughput={throughput:.2f} B/s")

    # Write result_table.csv
    with open("result_table.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "roll_no", "name", "mode", "bandwidth_mbps", "delay_ms",
            "message_size_bytes", "total_messages", "average_response_time_seconds",
            "throughput_bytes_per_second", "status"
        ])
        writer.writerows(result_rows)

    # Write message_response_log.csv
    with open("message_response_log.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "roll_no", "name", "mode", "message_size_bytes",
            "message_number", "response_time_seconds"
        ])
        writer.writerows(message_rows)

    print("\n[CLIENT] result_table.csv and message_response_log.csv written.")
    print("STATUS=SUCCESS")


if __name__ == "__main__":
    main()
