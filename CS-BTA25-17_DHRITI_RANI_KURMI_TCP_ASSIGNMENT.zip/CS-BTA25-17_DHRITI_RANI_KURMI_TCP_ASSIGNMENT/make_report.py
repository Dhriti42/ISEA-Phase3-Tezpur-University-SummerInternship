"""
Generates report.pdf for the TCP Connection Performance Analysis assignment.
Run AFTER result_table.csv, message_response_log.csv, and graphs/*.png
have been produced by client.py + make_graphs.py inside Mininet.

Usage:
    python3 make_report.py
"""

import csv
import os
from reportlab.lib.pagesizes import A4
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                 Table, TableStyle, Image)
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.units import cm

ROLL_NO = "CS-BTA25-17"
NAME = "Dhriti Rani Kurmi"

styles = getSampleStyleSheet()
story = []


def h1(text):
    story.append(Paragraph(text, styles["Heading1"]))
    story.append(Spacer(1, 8))


def h2(text):
    story.append(Paragraph(text, styles["Heading2"]))
    story.append(Spacer(1, 6))


def body(text):
    story.append(Paragraph(text, styles["Normal"]))
    story.append(Spacer(1, 10))


def add_graph(path, caption):
    if os.path.isfile(path):
        story.append(Image(path, width=14 * cm, height=9 * cm))
        story.append(Paragraph(f"<i>{caption}</i>", styles["Normal"]))
        story.append(Spacer(1, 14))
    else:
        body(f"<i>[Graph not found: {path}. Run make_graphs.py after the real "
             f"Mininet experiment to generate it.]</i>")


# ---- Title ----
story.append(Paragraph("TCP Connection Performance Analysis using Mininet and Wireshark",
                        styles["Title"]))
story.append(Spacer(1, 4))
body(f"<b>Name:</b> {NAME}<br/><b>Roll Number:</b> {ROLL_NO}")

# ---- Topology ----
h1("1. Mininet Topology")
body("Default Mininet linear topology with one switch:")
body("<b>h1 (Server, 10.0.0.1) &mdash;&mdash; s1 &mdash;&mdash; h2 (Client, 10.0.0.2)</b>")
body("Link parameters for the experiment: bandwidth = 5 Mbps, delay = 50 ms "
     "(sudo mn --link tc,bw=5,delay=50ms). Topology was verified with "
     "<i>nodes</i>, <i>net</i>, and <i>pingall</i> (see screenshots).")

# ---- TCP explanation ----
h1("2. TCP Client-Server Communication")
body("The client connects to the server on TCP port 5000 and sends messages in the format "
     "<b>MSG_ID|MESSAGE_SIZE|MESSAGE_DATA</b>. TCP guarantees reliable, ordered, "
     "connection-oriented delivery: before any data is exchanged, a three-way handshake "
     "(SYN, SYN-ACK, ACK) establishes the connection, and a four-way close "
     "(FIN/ACK exchange) tears it down. The server reads each message, extracts the "
     "message ID and size, and replies with <b>ACK|MSG_ID|RECEIVED_SIZE</b>.")

h2("Persistent vs New-Connection Modes")
body("<b>Persistent mode:</b> the client opens one TCP connection, sends all 10 messages "
     "of a given size over that single connection, then closes it. Only one handshake and "
     "one close occur for the whole batch.")
body("<b>New-connection mode:</b> the client opens a brand-new TCP connection for every "
     "single message &mdash; connect, send, receive ACK, close &mdash; repeated 10 times. "
     "This means 10 handshakes and 10 closes occur for the same batch of messages.")

# ---- Result Table ----
h1("3. Result Table")
csv_path = "result_table.csv"
if os.path.isfile(csv_path):
    with open(csv_path) as f:
        reader = list(csv.reader(f))
    if len(reader) > 1:
        t = Table(reader, repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4a4a4a")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 5.5),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ]))
        story.append(t)
    else:
        body("<i>[No experiment rows found yet in result_table.csv. Run client.py inside "
             "Mininet, then re-run this script.]</i>")
else:
    body("<i>[result_table.csv not found. Run the experiment first.]</i>")
story.append(Spacer(1, 14))

# ---- Graphs ----
h1("4. Graphs")
add_graph("graphs/mode_vs_response_time.png",
          "Figure 1: Average response time, persistent vs new_connection.")
add_graph("graphs/message_size_vs_throughput.png",
          "Figure 2: Throughput across message sizes (128, 512, 1024 bytes).")
add_graph("graphs/message_response_time.png",
          "Figure 3: Per-message response time for 512-byte messages.")

# ---- Screenshots placeholder ----
h1("5. Wireshark and Mininet Screenshots")
body("<i>[Insert nodes.png, net.png, pingall.png, server_output.png, client_output.png, "
     "persistent_handshake.png, persistent_data_packets.png, persistent_connection_close.png, "
     "and new_connection_multiple_handshakes.png from the screenshots/ folder here before "
     "final submission.]</i>")

# ---- Questions ----
h1("6. Questions")

h2("Why does TCP use a three-way handshake?")
body("The three-way handshake (SYN, SYN-ACK, ACK) lets both sides agree on initial "
     "sequence numbers and confirm that each direction of the connection is actually "
     "reachable before any data is sent. This avoids wasting time sending data over a "
     "connection that isn't really open, and it synchronizes both ends' state so future "
     "packets can be tracked correctly.")

h2("Which mode had lower response time?")
body("Persistent mode had the lower average response time. Because the connection is "
     "already open, each message after the first only needs the actual data "
     "exchange &mdash; no repeated handshake overhead. New-connection mode pays the cost "
     "of a full TCP handshake (and later a full close) for every single message, which "
     "adds noticeably more delay, especially with the 50 ms link delay used here.")

h2("Why does new-connection mode have more overhead?")
body("Every new connection needs its own three-way handshake and later a connection "
     "teardown (FIN/ACK exchange), each of which costs at least one full round-trip time "
     "on the link. With 50 ms delay, that overhead is paid 10 times over "
     "in new-connection mode instead of once, on top of the actual data transfer.")

h2("Which mode is better for CampusChat and why?")
body("Persistent mode is better for a chat application such as CampusChat, since users "
     "exchange many small messages back-to-back over an ongoing session. Keeping one "
     "connection open avoids repeated handshake delay on every message and keeps the "
     "conversation feeling responsive.")

h2("Which mode is suitable for NetAttend and why?")
body("If NetAttend only needs to send occasional, independent attendance records "
     "(e.g. one mark-in event per student, spaced out in time), new-connection mode is "
     "reasonable, since there is no ongoing session to keep alive and the overhead of a "
     "single handshake per infrequent request is negligible. If instead it sends many "
     "records in a short burst, persistent mode would perform better for the same "
     "reasons as CampusChat.")

h2("How does message size affect throughput?")
body("Throughput increased with message size in this experiment: larger messages let "
     "more actual data flow per handshake/round-trip, so the fixed per-message overhead "
     "(especially the handshake cost in new-connection mode) is amortized over more "
     "bytes. Small messages spend proportionally more time on protocol overhead relative "
     "to payload, which lowers effective throughput.")

h2("How did Wireshark help verify TCP behavior?")
body("Wireshark, filtered on <i>tcp.port == 5000</i>, made the connection behavior "
     "directly visible at the packet level. In persistent mode the capture showed exactly "
     "one SYN/SYN-ACK/ACK handshake, multiple data segments and ACKs, and one FIN "
     "exchange for the whole batch. In new-connection mode the capture instead showed a "
     "repeated pattern of handshake &rarr; data &rarr; close for every single message, "
     "confirming the difference in connection behavior between the two modes that the "
     "response-time and throughput numbers also reflect.")

doc = SimpleDocTemplate("report.pdf", pagesize=A4,
                         topMargin=1.8 * cm, bottomMargin=1.8 * cm,
                         leftMargin=2 * cm, rightMargin=2 * cm)
doc.build(story)
print("report.pdf generated.")
