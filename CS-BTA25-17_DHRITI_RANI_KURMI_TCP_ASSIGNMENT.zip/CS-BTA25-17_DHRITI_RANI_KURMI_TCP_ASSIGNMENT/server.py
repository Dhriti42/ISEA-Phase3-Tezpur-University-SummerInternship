"""
TCP Connection Performance Analysis - SERVER (h1)
Roll No: CS-BTA25-17
Name: Dhriti Rani Kurmi

Run this on h1 inside Mininet:
    h1 python3 server.py

The server works for BOTH client modes automatically:
 - persistent:      client opens one connection, sends many messages, closes at the end
 - new_connection:  client opens a new connection for every single message

For every connection, the server keeps reading messages of the form
    MSG_ID|MESSAGE_SIZE|MESSAGE_DATA
until the client closes that connection, replying to each with
    ACK|MSG_ID|RECEIVED_SIZE

All events are appended to server_log.txt as:
    timestamp,client_ip,mode,msg_id,received_size,ack_sent
"""

import socket
import datetime
import threading

SERVER_IP = "0.0.0.0"
SERVER_PORT = 5000
LOG_FILE = "server_log.txt"
log_lock = threading.Lock()


def log_event(client_ip, mode, msg_id, received_size, ack_sent):
    timestamp = datetime.datetime.now().isoformat()
    line = f"{timestamp},{client_ip},{mode},{msg_id},{received_size},{ack_sent}\n"
    with log_lock:
        with open(LOG_FILE, "a") as f:
            f.write(line)


def recv_line(conn):
    """Receive one '|' delimited message. Returns None if connection closed."""
    buf = b""
    while b"\n" not in buf:
        chunk = conn.recv(4096)
        if not chunk:
            return None if not buf else buf.decode()
        buf += chunk
    line, _, _ = buf.partition(b"\n")
    return line.decode()


def handle_connection(conn, addr):
    client_ip = addr[0]
    mode_known = None
    try:
        while True:
            line = recv_line(conn)
            if line is None or line == "":
                break

            try:
                msg_id_str, size_str, mode_and_data = line.split("|", 2)
                # mode is prepended by client for logging purposes:
                # format actually sent: MSG_ID|MESSAGE_SIZE|MODE|MESSAGE_DATA
                mode, message_data = mode_and_data.split("|", 1)
                msg_id = int(msg_id_str)
                declared_size = int(size_str)
            except ValueError:
                print(f"[SERVER] Malformed line from {client_ip}: {line[:50]}")
                continue

            mode_known = mode
            received_size = len(message_data)

            ack = f"ACK|{msg_id}|{received_size}\n"
            conn.sendall(ack.encode())

            log_event(client_ip, mode, msg_id, received_size, ack.strip())
            print(f"[SERVER] mode={mode} msg_id={msg_id} received_size={received_size} "
                  f"-> sent {ack.strip()}")

            if mode == "new_connection":
                # New-connection mode: one message per connection, then close.
                break
    finally:
        conn.close()


def main():
    open(LOG_FILE, "a").close()  # ensure file exists

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((SERVER_IP, SERVER_PORT))
    sock.listen(20)
    print(f"[SERVER] Listening on {SERVER_IP}:{SERVER_PORT} ...")
    print("[SERVER] Press Ctrl+C to stop.")

    try:
        while True:
            conn, addr = sock.accept()
            t = threading.Thread(target=handle_connection, args=(conn, addr), daemon=True)
            t.start()
    except KeyboardInterrupt:
        print("\n[SERVER] Shutting down. STATUS=SUCCESS")
    finally:
        sock.close()


if __name__ == "__main__":
    main()
