"""
Generates the 3 required graphs from result_table.csv and
message_response_log.csv (produced by client.py after a real run).

Run AFTER client.py has produced both CSV files:
    python3 make_graphs.py
"""

import csv
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

os.makedirs("graphs", exist_ok=True)


def read_csv(path):
    with open(path) as f:
        return list(csv.DictReader(f))


def graph_mode_vs_response_time(rows):
    modes = ["persistent", "new_connection"]
    avgs = []
    for mode in modes:
        vals = [float(r["average_response_time_seconds"]) for r in rows if r["mode"] == mode]
        avgs.append(sum(vals) / len(vals) if vals else 0)

    plt.figure(figsize=(6, 4))
    plt.bar(modes, avgs, color=["#4a90d9", "#d9764a"])
    plt.xlabel("Mode")
    plt.ylabel("Average Response Time (seconds)")
    plt.title("Mode vs Average Response Time")
    plt.tight_layout()
    plt.savefig("graphs/mode_vs_response_time.png", dpi=150)
    plt.close()
    print("Saved graphs/mode_vs_response_time.png")


def graph_message_size_vs_throughput(rows):
    sizes = [128, 512, 1024]
    plt.figure(figsize=(6, 4))
    for mode, color in [("persistent", "#4a90d9"), ("new_connection", "#d9764a")]:
        throughputs = []
        for size in sizes:
            vals = [float(r["throughput_bytes_per_second"]) for r in rows
                     if r["mode"] == mode and int(r["message_size_bytes"]) == size]
            throughputs.append(vals[0] if vals else 0)
        plt.plot(sizes, throughputs, marker="o", label=mode, color=color)

    plt.xlabel("Message Size (bytes)")
    plt.ylabel("Throughput (bytes/second)")
    plt.title("Message Size vs Throughput")
    plt.xticks(sizes)
    plt.legend()
    plt.tight_layout()
    plt.savefig("graphs/message_size_vs_throughput.png", dpi=150)
    plt.close()
    print("Saved graphs/message_size_vs_throughput.png")


def graph_message_response_time(msg_rows):
    plt.figure(figsize=(6, 4))
    for mode, color in [("persistent", "#4a90d9"), ("new_connection", "#d9764a")]:
        filtered = [r for r in msg_rows if r["mode"] == mode and
                    int(r["message_size_bytes"]) == 512]
        filtered.sort(key=lambda r: int(r["message_number"]))
        x = [int(r["message_number"]) for r in filtered]
        y = [float(r["response_time_seconds"]) for r in filtered]
        plt.plot(x, y, marker="o", label=mode, color=color)

    plt.xlabel("Message Number")
    plt.ylabel("Response Time (seconds)")
    plt.title("Response Time per Message (512-byte messages)")
    plt.legend()
    plt.tight_layout()
    plt.savefig("graphs/message_response_time.png", dpi=150)
    plt.close()
    print("Saved graphs/message_response_time.png")


def main():
    if not (os.path.isfile("result_table.csv") and os.path.isfile("message_response_log.csv")):
        print("ERROR: result_table.csv and message_response_log.csv must exist first. "
              "Run client.py inside Mininet before this script.")
        return

    result_rows = read_csv("result_table.csv")
    msg_rows = read_csv("message_response_log.csv")

    graph_mode_vs_response_time(result_rows)
    graph_message_size_vs_throughput(result_rows)
    graph_message_response_time(msg_rows)


if __name__ == "__main__":
    main()
