Assignment 7 screenshot checklist

Capture and save these images in this directory:

1. gui_login_success.png       - successful login in the GUI
2. gui_authenticated_message.png - message accepted after authentication
3. gui_duplicate_login.png     - second login rejected
4. gui_lockout.png             - account locked after five failed attempts
5. wireshark_login.png         - filter tcp.port == 5000, successful login
6. wireshark_failed_login.png  - failed login packet exchange
7. wireshark_logout.png        - logout packet exchange

The images must be captured from the student's own Mininet/Wireshark run.