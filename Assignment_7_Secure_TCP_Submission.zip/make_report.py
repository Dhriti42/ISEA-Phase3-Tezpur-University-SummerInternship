"""Build report.pdf from the assignment implementation notes."""

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    PageBreak, Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table,
    TableStyle,
)


OUTPUT = "report.pdf"
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(
    name="ReportTitle", parent=styles["Title"], alignment=TA_CENTER,
    textColor=colors.HexColor("#285d8f"), fontSize=18, leading=23,
    spaceAfter=12,
))
styles.add(ParagraphStyle(
    name="Section", parent=styles["Heading2"], textColor=colors.HexColor("#285d8f"),
    spaceBefore=10, spaceAfter=5,
))
styles.add(ParagraphStyle(
    name="Small", parent=styles["BodyText"], fontSize=8.5, leading=11,
))


def p(text, style="BodyText"):
    return Paragraph(text, styles[style])


story = [
    p("Assignment 7: Secure Network Application Development Using TCP", "ReportTitle"),
    p("<b>Student:</b> ____________________ &nbsp;&nbsp; <b>Roll number:</b> ____________________"),
    p("<b>Repository:</b> ____________________"),
    Spacer(1, 8),
    p("Objective", "Section"),
    p("The objective was to enhance a GUI-based multi-client TCP application with practical security controls. The implementation keeps the GUI separate from the networking layer and uses a newline-delimited JSON protocol over TCP port 5000."),
    p("Security Features Implemented", "Section"),
]

features = [
    ["Feature", "Implementation"],
    ["User authentication", "Username/password login with generic invalid-credential errors."],
    ["Secure password storage", "SHA-256 hexadecimal digests in users.json; no plaintext passwords."],
    ["Duplicate-login prevention", "In-memory active-session table rejects concurrent use of one username."],
    ["Input validation", "Username format, empty passwords/messages, 1024-character limit and command allow-list."],
    ["Failed-login protection", "Five consecutive failures trigger a temporary 60-second lockout."],
    ["Session management", "Logout plus five-minute inactivity timeout."],
    ["Secure logging", "Thread-safe security events without password values."],
    ["GUI authorization", "Send control remains disabled until successful authentication."],
]
story.append(Table(features, colWidths=[47 * mm, 123 * mm], repeatRows=1, style=TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dceaf7")),
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#19324d")),
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
    ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#7894ad")),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("LEADING", (0, 0), (-1, -1), 10),
    ("LEFTPADDING", (0, 0), (-1, -1), 5),
    ("RIGHTPADDING", (0, 0), (-1, -1), 5),
])))
story += [
    p("Assignment compatibility note: the brief explicitly requests SHA-256. For a production system, SHA-256 alone is not sufficient for password storage; a salted, slow KDF such as Argon2id or scrypt should be used."),
    p("System Architecture", "Section"),
    Preformatted(
        "+------------------+       TCP :5000       +---------------------------+\n"
        "| client_gui.py    | <-------------------> | server.py                 |\n"
        "| Tkinter +        |   newline JSON         | auth, validation, lockout |\n"
        "| independent      |                        | sessions + secure logs    |\n"
        "| TCPClient        |                        +-------------+-------------+\n"
        "+------------------+                                      |\n"
        "                                              +-----------v-----------+\n"
        "                                              | users.json            |\n"
        "                                              | SHA-256 digests only  |\n"
        "                                              +-----------------------+",
        styles["Code"],
    ),
    p("Implementation", "Section"),
    p("The server validates the username before authentication, hashes the submitted password with hashlib.sha256(), and compares the digest with users.json. It never returns the digest or logs the password. Successful sessions are kept in an active_users table protected by a re-entrant lock. Failed attempts are tracked per username, with a lockout after the fifth failure."),
    p("Each client is handled in a daemon thread. The handler records the last request time and expires an authenticated connection after five minutes of inactivity. The security logger uses a thread lock and an allow-list for details to avoid accidental password or control-character logging."),
    p("Testing", "Section"),
    p("Command used:"),
    Preformatted("python -m unittest discover -s tests -v", styles["Code"]),
]

tests = [
    ["Test", "Result"],
    ["Successful authentication and authenticated message", "PASS"],
    ["Duplicate-login rejection", "PASS"],
    ["Five-failure lockout", "PASS"],
    ["Unauthenticated access and input validation", "PASS"],
    ["Inactivity timeout", "PASS"],
    ["Password absent from security log", "PASS"],
]
story += [
    Table(tests, colWidths=[130 * mm, 40 * mm], repeatRows=1, style=TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dceaf7")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("TEXTCOLOR", (1, 1), (1, -1), colors.HexColor("#19733a")),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#7894ad")),
        ("FONTSIZE", (0, 0), (-1, -1), 8.8),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ])),
    p("Result: 6 tests passed.", "Small"),
    p("Wireshark Verification", "Section"),
    p("Required display filter:"),
    Preformatted("tcp.port == 5000", styles["Code"]),
    p("Capture successful login, failed login, authenticated communication and logout in the Mininet environment. The capture files and screenshots must be produced by the student because this workspace does not have access to the student's Mininet interfaces or Wireshark desktop. The repository includes a screenshot checklist."),
    p("Conclusion", "Section"),
    p("The application adds authentication, hashed credential storage, session controls, validation, lockout handling and secure logging to the TCP client/server design. Automated tests verify the main security behaviors. Before submission, run the GUI in the lab, add Wireshark screenshots, update the Assignment 6 public repository and include the handwritten reflection scan."),
]

doc = SimpleDocTemplate(
    OUTPUT, pagesize=A4, rightMargin=18 * mm, leftMargin=18 * mm,
    topMargin=16 * mm, bottomMargin=16 * mm,
    title="Assignment 7 Secure TCP Application Report",
)
doc.build(story)
print(OUTPUT)