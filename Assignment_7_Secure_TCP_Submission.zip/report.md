# Assignment 7: Secure Network Application Development Using TCP

**Student:** ____________________  
**Roll number:** ____________________  
**Repository:** ____________________

## Objective

The objective was to enhance a GUI-based multi-client TCP application with
practical security controls. The implementation keeps the GUI separate from
the networking layer and uses a newline-delimited JSON protocol over TCP port
5000.

## Security Features Implemented

1. **User authentication:** The server accepts a username and password through
   the `login` command and returns a generic error for invalid credentials.
2. **Secure password storage:** `users.json` stores only SHA-256 hexadecimal
   digests. Password strings are not written to the security log.
3. **Duplicate-login prevention:** An in-memory `active_users` table rejects a
   second connection for an already authenticated username.
4. **Input validation:** Usernames must contain 3–20 letters, digits or
   underscores. Empty passwords, empty messages, messages over 1024 characters
   and unsupported commands are rejected.
5. **Failed-login protection:** Five consecutive failures temporarily lock the
   username for 60 seconds.
6. **Session management:** Authenticated sessions can log out and expire after
   five minutes of inactivity.
7. **Secure logging:** Thread-safe logs record security events, usernames and
   network addresses but never password values.
8. **GUI access control:** The Send control is disabled until authentication
   succeeds.

> **Assignment compatibility note:** The brief explicitly requests SHA-256.
> For a production system, SHA-256 alone is not sufficient for password
> storage; a salted, slow KDF such as Argon2id or scrypt should be used.

## System Architecture

```text
+----------------------+       TCP :5000        +---------------------------+
| client_gui.py        | <--------------------> | server.py                 |
| Tkinter presentation |  newline JSON messages | threaded client handlers   |
| TCPClient networking |                         | authentication/session    |
+----------------------+                         | validation + lockout      |
                                                  | secure logging             |
                                                  +-------------+-------------+
                                                                |
                                                   +------------+------------+
                                                   | users.json             |
                                                   | SHA-256 digests only   |
                                                   +-------------------------+
```

The server uses a listening socket and one daemon thread per connected client.
Shared authentication state is protected by a re-entrant lock. The GUI calls
the independent `TCPClient` layer from background threads so network delays do
not freeze the interface.

## Implementation

### Authentication and password hashing

The server validates the username format before authentication. It hashes the
submitted password with `hashlib.sha256()` and compares the resulting digest
with the digest loaded from `users.json`. The server never returns the stored
digest and never logs the password.

### Duplicate login and lockout

Successful sessions are stored as `username -> socket`. If the username is
already present, the second login is rejected. Failed attempts are tracked
per username. On the fifth failure, the username receives a temporary
lockout. A successful login clears the failure counter.

### Session timeout and logging

The handler records the time of the most recent request. An authenticated
connection with no activity for five minutes receives a timeout response and
is closed. Security events use a thread-safe file logger with an allow-list for
log details, preventing arbitrary message content from being inserted as
untrusted log metadata.

## Testing

Automated protocol tests were run with:

```bash
python -m unittest discover -s tests -v
```

Result: **6 tests passed**.

The tests cover:

- successful authentication and an authenticated message;
- duplicate-login rejection;
- five-failure lockout;
- unauthenticated access and invalid command/username validation;
- inactivity timeout;
- confirmation that the password is absent from the security log.

## Wireshark Verification

The required display filter is:

```text
tcp.port == 5000
```

The student must run the server/client in the Mininet topology and attach
screenshots or a capture showing:

| Capture | Expected evidence |
| --- | --- |
| Successful login | TCP stream contains a successful authentication response |
| Failed login | TCP stream contains a generic invalid-credentials response |
| Authenticated communication | `send` is accepted after login |
| Logout | Server returns a logout response and closes the session |

Because this workspace cannot access the student's Mininet interfaces or
Wireshark desktop, these captures are intentionally left as a submission
step rather than fabricated.

## Conclusion

The application now adds authentication, hashed credential storage, session
controls, validation, lockout handling and security logging to the TCP
client/server design. The automated tests verify the main security behaviors.
Before submission, the student should run the GUI in the lab, produce the
Wireshark screenshots, update the Assignment 6 public repository, and add the
handwritten reflection scan.