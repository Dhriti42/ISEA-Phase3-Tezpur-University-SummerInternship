import json
import socket
import tempfile
import time
import unittest
from pathlib import Path
from threading import Thread

from server import SecureTCPServer, hash_password


class ProtocolClient:
    def __init__(self, port: int):
        self.sock = socket.create_connection(("127.0.0.1", port), timeout=2)
        self.file = self.sock.makefile("r", encoding="utf-8")
        self.read()

    def read(self):
        return json.loads(self.file.readline())

    def request(self, payload):
        self.sock.sendall((json.dumps(payload) + "\n").encode())
        return self.read()

    def close(self):
        self.file.close()
        self.sock.close()


class Assignment7Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        users = root / "users.json"
        users.write_text(json.dumps({"alice": hash_password("Password123!")}))
        self.server = SecureTCPServer(
            host="127.0.0.1", port=0,
            users_file=users, log_file=root / "security_log.txt",
            session_timeout=1, lockout_seconds=1,
        )
        self.server.start()
        time.sleep(0.05)

    def tearDown(self):
        self.server.stop()
        self.temp.cleanup()

    def test_successful_authentication_and_message(self):
        client = ProtocolClient(self.server.port)
        self.assertTrue(client.request({
            "command": "login", "username": "alice", "password": "Password123!"
        })["ok"])
        result = client.request({"command": "send", "message": "hello"})
        self.assertTrue(result["ok"])
        client.close()

    def test_duplicate_login_is_rejected(self):
        first = ProtocolClient(self.server.port)
        second = ProtocolClient(self.server.port)
        self.assertTrue(first.request({
            "command": "login", "username": "alice", "password": "Password123!"
        })["ok"])
        result = second.request({
            "command": "login", "username": "alice", "password": "Password123!"
        })
        self.assertFalse(result["ok"])
        self.assertIn("already", result["error"].lower())
        first.close()
        second.close()

    def test_failed_login_lockout(self):
        client = ProtocolClient(self.server.port)
        for _ in range(5):
            result = client.request({
                "command": "login", "username": "alice", "password": "wrong"
            })
            self.assertFalse(result["ok"])
        result = client.request({
            "command": "login", "username": "alice", "password": "Password123!"
        })
        self.assertFalse(result["ok"])
        self.assertIn("locked", result["error"].lower())
        client.close()

    def test_validation_and_authentication_required(self):
        client = ProtocolClient(self.server.port)
        self.assertFalse(client.request({"command": "send", "message": "x"})["ok"])
        self.assertFalse(client.request({"command": "nope"})["ok"])
        self.assertFalse(client.request({
            "command": "login", "username": "bad username", "password": "x"
        })["ok"])
        client.close()

    def test_inactivity_timeout(self):
        client = ProtocolClient(self.server.port)
        self.assertTrue(client.request({
            "command": "login", "username": "alice", "password": "Password123!"
        })["ok"])
        time.sleep(1.2)
        result = client.request({"command": "ping"})
        self.assertFalse(result["ok"])
        self.assertIn("timed out", result["error"].lower())
        client.close()

    def test_log_never_contains_password(self):
        client = ProtocolClient(self.server.port)
        client.request({
            "command": "login", "username": "alice", "password": "Password123!"
        })
        client.request({"command": "logout"})
        client.close()
        log = (Path(self.temp.name) / "security_log.txt").read_text()
        self.assertNotIn("Password123!", log)
        self.assertIn("LOGIN_SUCCESS", log)
        self.assertIn("LOGOUT", log)


if __name__ == "__main__":
    unittest.main()