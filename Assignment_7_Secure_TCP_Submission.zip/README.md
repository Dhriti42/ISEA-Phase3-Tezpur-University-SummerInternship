# Assignment 7 — Secure TCP Network Application

This implementation extends the Assignment 6-style threaded TCP pattern with
application security controls. The protocol is newline-delimited JSON and the
GUI is kept separate from the networking class in `client_gui.py`.

## Run it

```bash
python server.py
# In another terminal:
python client_gui.py
```

The server listens on TCP port `5000`. The first run creates `users.json` if it
does not exist. Demo credentials are `alice` / `Password123!`; only the
SHA-256 digest is stored. Change the demo credential before publishing a
public repository.

## Mininet verification

```bash
sudo mn --topo single,5
nodes
net
pingall
```

Run the server on one Mininet host and the GUI/client from another host using
the server host's Mininet IP. Use Wireshark display filter:

```text
tcp.port == 5000
```

Capture these four flows: successful login, failed login, authenticated
communication, and logout. The protocol is intentionally not TLS because the
assignment asks for practical application security and Wireshark verification;
passwords are hashed at rest, but plaintext credentials should not be
considered safe in transit.

## Security features

- Username and password authentication.
- SHA-256 password hashes in `users.json`, never plaintext passwords.
- Duplicate-login prevention using an in-memory active-session table.
- Validation for usernames, empty passwords, empty/oversized messages, and
  unsupported commands.
- Five failed attempts trigger a temporary 60-second lockout.
- Logout and five-minute inactivity timeout.
- Thread-safe security logging with no password values.
- GUI controls are disabled until authentication succeeds.

## Files

| File | Purpose |
| --- | --- |
| `server.py` | Secure threaded TCP server |
| `client_gui.py` | Tkinter GUI and independent TCP client |
| `users.json` | SHA-256 credential database |
| `security_log.txt` | Runtime security events |
| `tests/test_assignment7.py` | Automated protocol/security tests |
| `report.pdf` | Assignment report |
| `reflection_answers_for_handwriting.txt` | Answers to copy by hand |

## Important submission items

The Wireshark capture files and handwritten reflection must be produced by the
student in the lab environment. This workspace contains the commands and a
reflection guide, but does not pretend that a network capture or handwritten
scan exists when it has not been performed.