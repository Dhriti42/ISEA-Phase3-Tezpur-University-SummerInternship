"""Secure multi-client TCP server for Assignment 7.

Protocol
--------
Each request and response is one UTF-8 JSON object terminated by ``\n``.
Supported commands are ``login``, ``send``, ``whoami``, ``ping`` and
``logout``.  Passwords are used only during login and are never written to
the log or sent back in a response.

This assignment explicitly requests SHA-256, so this implementation uses
SHA-256 for compatibility with the rubric.  A production application should
use a slow salted password KDF such as Argon2id or scrypt instead.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import socket
import threading
import time
from pathlib import Path
from typing import Any

HOST = "0.0.0.0"
PORT = 5000
MAX_MESSAGE_LENGTH = 1024
SESSION_TIMEOUT_SECONDS = 300
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_SECONDS = 60
USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_]{3,20}$")
SUPPORTED_COMMANDS = {"login", "send", "whoami", "ping", "logout"}

BASE_DIR = Path(__file__).resolve().parent
USERS_FILE = BASE_DIR / "users.json"
LOG_FILE = BASE_DIR / "security_log.txt"


def hash_password(password: str) -> str:
    """Return the assignment-required SHA-256 password hash."""

    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def valid_username(username: Any) -> bool:
    return isinstance(username, str) and USERNAME_PATTERN.fullmatch(username) is not None


def load_or_create_users(path: Path = USERS_FILE) -> dict[str, str]:
    """Load hashed credentials, creating a safe demo account on first run."""

    if not path.exists():
        path.write_text(
            json.dumps({"alice": hash_password("Password123!")}, indent=2) + "\n",
                       encoding="utf-8")
        return {"alice": hash_password("Password123!")}

    try:
        users = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Could not read {path}: {exc}") from exc
    if not isinstance(users, dict) or any(
        not valid_username(user) or not isinstance(digest, str)
        or not re.fullmatch(r"[0-9a-f]{64}", digest)
        for user, digest in users.items()
    ):
        raise RuntimeError("users.json must map valid usernames to SHA-256 hashes")
    return users


class SecurityLog:
    """Thread-safe security logger that deliberately excludes passwords."""

    def __init__(self, path: Path = LOG_FILE) -> None:
        self.path = path
        self._lock = threading.Lock()
        self._logger = logging.getLogger("secure_tcp")
        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False
        if not self._logger.handlers:
            handler = logging.FileHandler(self.path, encoding="utf-8")
            handler.setFormatter(logging.Formatter("%(asctime)sZ %(message)s"))
            self._logger.addHandler(handler)

    def event(self, name: str, username: str = "-", address: str = "-",
              details: str = "") -> None:
        # Only a small allow-list is written as details; arbitrary input could
        # otherwise forge log lines or accidentally contain sensitive data.
        safe_details = re.sub(r"[^A-Za-z0-9_.=:/ -]", "_", details)[:160]
        line = f"event={name} user={username[:20]} address={address[:80]}"
        if safe_details:
            line += f" details={safe_details}"
        with self._lock:
            self._logger.info(line)

    def close(self) -> None:
        for handler in self._logger.handlers:
            handler.close()
            self._logger.removeHandler(handler)


class SecureTCPServer:
    """Thread-per-client TCP server with authentication and session controls."""

    def __init__(
        self,
        host: str = HOST,
        port: int = PORT,
        users_file: Path = USERS_FILE,
        log_file: Path = LOG_FILE,
        session_timeout: int = SESSION_TIMEOUT_SECONDS,
        lockout_seconds: int = LOCKOUT_SECONDS,
    ) -> None:
        self.host = host
        self.port = port
        self.users_file = users_file
        self.users = load_or_create_users(users_file)
        self.session_timeout = session_timeout
        self.lockout_seconds = lockout_seconds
        self.security_log = SecurityLog(log_file)
        self._state_lock = threading.RLock()
        self._failed_attempts: dict[str, tuple[int, float]] = {}
        self._active_users: dict[str, socket.socket] = {}
        self._clients: set[socket.socket] = set()
        self._stop_event = threading.Event()
        self._listener: socket.socket | None = None
        self._accept_thread: threading.Thread | None = None

    def start(self) -> None:
        if self._accept_thread and self._accept_thread.is_alive():
            return
        self._stop_event.clear()
        self._listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._listener.bind((self.host, self.port))
        self._listener.listen(20)
        self.port = self._listener.getsockname()[1]
        self._accept_thread = threading.Thread(target=self._accept_loop,
                                                name="tcp-accept", daemon=True)
        self._accept_thread.start()
        print(f"Secure TCP server listening on {self.host}:{self.port}")

    def serve_forever(self) -> None:
        self.start()
        try:
            while not self._stop_event.wait(1):
                pass
        except KeyboardInterrupt:
            print("\nStopping server...")
        finally:
            self.stop()

    def stop(self) -> None:
        self._stop_event.set()
        listener, self._listener = self._listener, None
        if listener is not None:
            try:
                listener.close()
            except OSError:
                pass
        with self._state_lock:
            clients = list(self._clients)
        for client in clients:
            try:
                client.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                client.close()
            except OSError:
                pass
        if self._accept_thread and self._accept_thread is not threading.current_thread():
            self._accept_thread.join(timeout=2)
        self.security_log.close()

    def _accept_loop(self) -> None:
        assert self._listener is not None
        self._listener.settimeout(1)
        while not self._stop_event.is_set():
            try:
                conn, address = self._listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            with self._state_lock:
                self._clients.add(conn)
            self.security_log.event("CONNECTION", address=self._address(address))
            threading.Thread(
                target=self._handle_client,
                args=(conn, address),
                name=f"tcp-client-{address[0]}-{address[1]}",
                daemon=True,
            ).start()

    @staticmethod
    def _address(address: tuple[str, int] | Any) -> str:
        return f"{address[0]}:{address[1]}" if isinstance(address, tuple) else str(address)

    def _send(self, conn: socket.socket, payload: dict[str, Any]) -> None:
        conn.sendall((json.dumps(payload, separators=(",", ":")) + "\n").encode("utf-8"))

    def _handle_client(self, conn: socket.socket, address: tuple[str, int]) -> None:
        peer = self._address(address)
        buffer = bytearray()
        username: str | None = None
        last_activity = time.monotonic()
        conn.settimeout(1.0)
        try:
            self._send(conn, {"ok": True, "message": "Connected. Please log in."})
            while not self._stop_event.is_set():
                if username and time.monotonic() - last_activity > self.session_timeout:
                    self.security_log.event("SESSION_TIMEOUT", username, peer)
                    self._send(conn, {"ok": False, "error": "Session timed out due to inactivity."})
                    break
                try:
                    chunk = conn.recv(4096)
                except socket.timeout:
                    continue
                if not chunk:
                    break
                buffer.extend(chunk)
                if len(buffer) > MAX_MESSAGE_LENGTH * 4:
                    self._send(conn, {"ok": False, "error": "Request too large."})
                    break
                while b"\n" in buffer:
                    raw, _, remainder = buffer.partition(b"\n")
                    buffer = bytearray(remainder)
                    last_activity = time.monotonic()
                    try:
                        request = json.loads(raw.decode("utf-8"))
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        self._send(conn, {"ok": False, "error": "Invalid JSON request."})
                        continue
                    if not isinstance(request, dict):
                        self._send(conn, {"ok": False, "error": "Request must be a JSON object."})
                        continue
                    response, should_close, username = self._process_request(
                        conn, peer, request, username
                    )
                    self._send(conn, response)
                    if should_close:
                        return
        except (ConnectionError, OSError):
            pass
        finally:
            if username:
                with self._state_lock:
                    if self._active_users.get(username) is conn:
                        del self._active_users[username]
                self.security_log.event("DISCONNECT", username, peer)
            with self._state_lock:
                self._clients.discard(conn)
            try:
                conn.close()
            except OSError:
                pass

    def _process_request(
        self,
        conn: socket.socket,
        peer: str,
        request: dict[str, Any],
        username: str | None,
    ) -> tuple[dict[str, Any], bool, str | None]:
        command = request.get("command")
        if command not in SUPPORTED_COMMANDS:
            self.security_log.event("INVALID_COMMAND", username or "-", peer)
            return {"ok": False, "error": "Unsupported command."}, False, username

        if command == "login":
            if username is not None:
                return {"ok": False, "error": "Already authenticated."}, False, username
            new_username = request.get("username")
            password = request.get("password")
            if not valid_username(new_username):
                self.security_log.event("INVALID_USERNAME", "-", peer)
                return {"ok": False, "error": "Username must be 3-20 letters, numbers or underscores."}, False, None
            if not isinstance(password, str) or not password:
                self.security_log.event("INVALID_LOGIN_INPUT", new_username, peer)
                return {"ok": False, "error": "Password cannot be empty."}, False, None
            now = time.monotonic()
            with self._state_lock:
                failures, locked_until = self._failed_attempts.get(new_username, (0, 0))
                if locked_until > now:
                    remaining = max(1, int(locked_until - now))
                    self.security_log.event("LOGIN_BLOCKED", new_username, peer,
                                            f"remaining={remaining}s")
                    return {"ok": False, "error": "Account temporarily locked. Try again later."}, False, None
                if locked_until:
                    self._failed_attempts.pop(new_username, None)
                expected = self.users.get(new_username)
                authenticated = expected is not None and (
                    hashlib.sha256(password.encode("utf-8")).hexdigest() == expected
                )
                if not authenticated:
                    failures += 1
                    if failures >= MAX_FAILED_ATTEMPTS:
                        self._failed_attempts[new_username] = (failures, now + self.lockout_seconds)
                    else:
                        self._failed_attempts[new_username] = (failures, 0)
                    self.security_log.event("LOGIN_FAILURE", new_username, peer,
                                            f"attempt={failures}")
                    return {"ok": False, "error": "Invalid username or password."}, False, None
                if new_username in self._active_users:
                    self.security_log.event("DUPLICATE_LOGIN", new_username, peer)
                    return {"ok": False, "error": "User is already logged in."}, False, None
                self._failed_attempts.pop(new_username, None)
                self._active_users[new_username] = conn
            self.security_log.event("LOGIN_SUCCESS", new_username, peer)
            return {"ok": True, "message": "Authentication successful.", "username": new_username}, False, new_username

        if command == "logout":
            if username is None:
                return {"ok": False, "error": "Authentication required."}, True, None
            self.security_log.event("LOGOUT", username, peer)
            return {"ok": True, "message": "Logged out."}, True, None

        if command == "whoami":
            if username is None:
                return {"ok": False, "error": "Authentication required."}, False, None
            return {"ok": True, "username": username}, False, username

        if command == "ping":
            return {"ok": True, "message": "pong"}, False, username

        # send
        if username is None:
            self.security_log.event("UNAUTHENTICATED_COMMAND", "-", peer, "command=send")
            return {"ok": False, "error": "Authentication required."}, False, None
        message = request.get("message")
        if not isinstance(message, str) or not message.strip():
            return {"ok": False, "error": "Message cannot be empty."}, False, username
        if len(message) > MAX_MESSAGE_LENGTH:
            return {"ok": False, "error": "Message exceeds 1024 characters."}, False, username
        self.security_log.event("MESSAGE_SENT", username, peer, f"length={len(message)}")
        return {"ok": True, "message": "Message accepted.", "echo": message}, False, username


if __name__ == "__main__":
    SecureTCPServer().serve_forever()