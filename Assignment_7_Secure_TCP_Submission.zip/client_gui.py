"""Tkinter GUI client for the secure TCP assignment server."""

from __future__ import annotations

import json
import socket
import threading
import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk
from typing import Any


class TCPClient:
    """Small networking layer kept independent from the GUI."""

    def __init__(self, host: str = "127.0.0.1", port: int = 5000) -> None:
        self.host = host
        self.port = port
        self.socket: socket.socket | None = None
        self._file = None
        self._lock = threading.Lock()

    def connect(self) -> dict[str, Any]:
        self.socket = socket.create_connection((self.host, self.port), timeout=5)
        self.socket.settimeout(5)
        self._file = self.socket.makefile("r", encoding="utf-8")
        return self._read_response()

    def request(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.socket or not self._file:
            raise ConnectionError("Not connected")
        with self._lock:
            self.socket.sendall((json.dumps(payload) + "\n").encode("utf-8"))
            return self._read_response()

    def _read_response(self) -> dict[str, Any]:
        if not self._file:
            raise ConnectionError("Not connected")
        line = self._file.readline()
        if not line:
            raise ConnectionError("Server closed the connection")
        return json.loads(line)

    def close(self) -> None:
        if self._file:
            self._file.close()
            self._file = None
        if self.socket:
            try:
                self.socket.close()
            finally:
                self.socket = None


class SecureChatGUI:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Secure TCP Messenger")
        self.root.geometry("680x500")
        self.client = TCPClient()
        self.username: str | None = None

        self.host_var = tk.StringVar(value="127.0.0.1")
        self.port_var = tk.StringVar(value="5000")
        self.user_var = tk.StringVar()
        self.password_var = tk.StringVar()
        self.message_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Disconnected")

        connection = ttk.LabelFrame(root, text="Connection and authentication", padding=10)
        connection.pack(fill="x", padx=12, pady=12)
        ttk.Label(connection, text="Host").grid(row=0, column=0, sticky="w")
        ttk.Entry(connection, textvariable=self.host_var, width=18).grid(row=0, column=1, padx=6)
        ttk.Label(connection, text="Port").grid(row=0, column=2, sticky="w")
        ttk.Entry(connection, textvariable=self.port_var, width=8).grid(row=0, column=3, padx=6)
        ttk.Label(connection, text="Username").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(connection, textvariable=self.user_var, width=18).grid(row=1, column=1, padx=6, pady=(8, 0))
        ttk.Label(connection, text="Password").grid(row=1, column=2, sticky="w", pady=(8, 0))
        ttk.Entry(connection, textvariable=self.password_var, show="*", width=18).grid(row=1, column=3, padx=6, pady=(8, 0))
        self.login_button = ttk.Button(connection, text="Login", command=self.login)
        self.login_button.grid(row=1, column=4, padx=8, pady=(8, 0))
        self.logout_button = ttk.Button(connection, text="Logout", command=self.logout, state="disabled")
        self.logout_button.grid(row=1, column=5, pady=(8, 0))

        self.messages = scrolledtext.ScrolledText(root, state="disabled", wrap=tk.WORD)
        self.messages.pack(fill="both", expand=True, padx=12, pady=(0, 10))
        composer = ttk.Frame(root, padding=(12, 0, 12, 10))
        composer.pack(fill="x")
        self.message_entry = ttk.Entry(composer, textvariable=self.message_var, state="disabled")
        self.message_entry.pack(side="left", fill="x", expand=True)
        ttk.Button(composer, text="Send", command=self.send_message).pack(side="left", padx=(8, 0))
        ttk.Label(root, textvariable=self.status_var, anchor="w").pack(fill="x", padx=12, pady=(0, 8))
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def _run_network(self, action) -> None:
        threading.Thread(target=action, daemon=True).start()

    def _show_status(self, text: str) -> None:
        self.root.after(0, self.status_var.set, text)

    def _append(self, text: str) -> None:
        def update() -> None:
            self.messages.configure(state="normal")
            self.messages.insert(tk.END, text + "\n")
            self.messages.see(tk.END)
            self.messages.configure(state="disabled")
        self.root.after(0, update)

    def login(self) -> None:
        def action() -> None:
            try:
                if not self.client.socket:
                    greeting = self.client.connect()
                    if not greeting.get("ok"):
                        raise ConnectionError(greeting.get("error", "Connection failed"))
                response = self.client.request({
                    "command": "login",
                    "username": self.user_var.get(),
                    "password": self.password_var.get(),
                })
                if response.get("ok"):
                    self.username = response["username"]
                    self._show_status(f"Authenticated as {self.username}")
                    self.root.after(0, self.login_button.configure, {"state": "disabled"})
                    self.root.after(0, self.logout_button.configure, {"state": "normal"})
                    self.root.after(0, self.message_entry.configure, {"state": "normal"})
                    self._append("Login successful.")
                else:
                    self._show_status(response.get("error", "Login failed"))
                    self._append("Login failed: " + response.get("error", "Unknown error"))
            except (OSError, ValueError, ConnectionError) as exc:
                self._show_status(f"Connection error: {exc}")
        self._run_network(action)

    def send_message(self) -> None:
        message = self.message_var.get()
        if not message:
            return
        def action() -> None:
            try:
                response = self.client.request({"command": "send", "message": message})
                if response.get("ok"):
                    self._append(f"{self.username}: {message}")
                    self.root.after(0, self.message_var.set, "")
                else:
                    self._show_status(response.get("error", "Message rejected"))
            except (OSError, ValueError, ConnectionError) as exc:
                self._show_status(f"Send failed: {exc}")
        self._run_network(action)

    def logout(self) -> None:
        def action() -> None:
            try:
                self.client.request({"command": "logout"})
            except (OSError, ValueError, ConnectionError):
                pass
            self.client.close()
            self.username = None
            self._show_status("Logged out")
            self.root.after(0, self.login_button.configure, {"state": "normal"})
            self.root.after(0, self.logout_button.configure, {"state": "disabled"})
            self.root.after(0, self.message_entry.configure, {"state": "disabled"})
        self._run_network(action)

    def close(self) -> None:
        self.client.close()
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    SecureChatGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()