"""
Reliable UDP Communication - CLIENT (h2)
Roll No: CS-BTA25-17
Name: Dhriti Rani Kurmi

Run this on h2 inside Mininet:
    h2 python3 client.py <SERVER_IP> <LOSS_PERCENT_LABEL>

Example:
    h2 python3 client.py 10.0.0.1 0
    h2 python3 client.py 10.0.0.1 5
    h2 python3 client.py 10.0.0.1 10

<LOSS_PERCENT_LABEL> is only used for labeling the printed output / CSV row --
the ACTUAL packet loss is created by Mininet's tc when you start it with
    sudo mn --link tc,bw=5,delay=30ms,loss=<X>

Client responsibilities:
 1. Send one message at a time (Stop-and-Wait).
 2. Wait for the matching ACK.
 3. Retransmit the SAME packet if ACK not received within TIMEOUT.
 4. Count total packets sent (includes retransmissions).
 5. Count retransmissions.
 6. Measure total transfer time.

Roll number CS-BTA25-17 -> last digit 7 -> TIMEOUT = 1.2s (per assignment table)
"""

import socket
import sys
import time
import csv
import os

SERVER_PORT = 5000
TOTAL_MESSAGES = 10
TIMEOUT = 1.2  # seconds -- roll number last digit 7 => 1.2s


def run_client(server_ip, loss_label):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(TIMEOUT)

    total_packets_sent = 0
    total_retransmissions = 0

    start_time = time.time()

    for seq in range(1, TOTAL_MESSAGES + 1):
        message = f"Message {seq} from h2"
        packet = f"{seq}|{message}"

        acked = False
        while not acked:
            sock.sendto(packet.encode(), (server_ip, SERVER_PORT))
            total_packets_sent += 1

            try:
                data, _ = sock.recvfrom(4096)
                response = data.decode()
                ack_prefix, ack_seq_str = response.split("|", 1)

                if ack_prefix == "ACK" and int(ack_seq_str) == seq:
                    acked = True
                    print(f"[CLIENT] SEQ={seq} ACKed successfully.")
                else:
                    # Unexpected/old ACK -- ignore and keep waiting within same timeout window
                    print(f"[CLIENT] Ignoring unexpected response: {response}")

            except socket.timeout:
                total_retransmissions += 1
                print(f"[CLIENT] Timeout waiting for ACK of SEQ={seq}. Retransmitting... "
                      f"(retransmission #{total_retransmissions})")

    end_time = time.time()
    transfer_time = round(end_time - start_time, 4)

    sock.close()

    print("\n[CLIENT] ---- FINAL RESULTS ----")
    print(f"TOTAL_MESSAGES=10")
    print(f"LOSS_PERCENT={loss_label}")
    print(f"TIMEOUT={TIMEOUT}")
    print(f"TOTAL_PACKETS_SENT={total_packets_sent}")
    print(f"TOTAL_RETRANSMISSIONS={total_retransmissions}")
    print(f"TRANSFER_TIME_SECONDS={transfer_time}")
    print(f"STATUS=SUCCESS")

    return {
        "loss_percent": loss_label,
        "timeout": TIMEOUT,
        "total_messages": TOTAL_MESSAGES,
        "total_packets_sent": total_packets_sent,
        "total_retransmissions": total_retransmissions,
        "transfer_time_seconds": transfer_time,
        "status": "SUCCESS",
    }


def append_to_csv(result, roll_no="CS-BTA25-17", name="Dhriti Rani Kurmi",
                   csv_path="result_table.csv"):
    """Appends this run's result as one row of result_table.csv.
    Run the client 3 times (loss=0, loss=5, loss=10) and this file
    will end up with exactly the 3 required rows."""
    file_exists = os.path.isfile(csv_path)
    with open(csv_path, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow([
                "roll_no", "name", "loss_percent", "timeout", "total_messages",
                "total_packets_sent", "total_retransmissions",
                "transfer_time_seconds", "status"
            ])
        writer.writerow([
            roll_no, name, result["loss_percent"], result["timeout"],
            result["total_messages"], result["total_packets_sent"],
            result["total_retransmissions"], result["transfer_time_seconds"],
            result["status"]
        ])
    print(f"[CLIENT] Row appended to {csv_path}")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 client.py <SERVER_IP> <LOSS_PERCENT_LABEL>")
        print("Example: python3 client.py 10.0.0.1 0")
        sys.exit(1)

    server_ip = sys.argv[1]
    loss_label = sys.argv[2]

    result = run_client(server_ip, loss_label)
    append_to_csv(result)
