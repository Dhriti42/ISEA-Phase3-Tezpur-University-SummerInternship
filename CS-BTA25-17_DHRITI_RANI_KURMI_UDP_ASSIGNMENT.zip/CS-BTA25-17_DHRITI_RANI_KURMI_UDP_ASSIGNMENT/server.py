"""
Reliable UDP Communication - SERVER (h1)
Roll No: CS-BTA25-17
Name: Dhriti Rani Kurmi

Run this on h1 inside Mininet:
    h1 python3 server.py

Server responsibilities:
 1. Receive messages of format  SEQ|MESSAGE
 2. Send back an ACK of format ACK|SEQ
 3. Detect duplicate messages (same SEQ received more than once)
 4. Count unique messages received
 5. Count duplicate messages
 6. Stop after receiving 10 unique messages (matches assignment spec)
"""

import socket

SERVER_IP = "0.0.0.0"     # listen on all interfaces (h1 will actually be 10.0.0.1)
SERVER_PORT = 5000
TOTAL_MESSAGES_EXPECTED = 10


def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((SERVER_IP, SERVER_PORT))
    print(f"[SERVER] Listening on {SERVER_IP}:{SERVER_PORT} ...")

    received_seqs = set()
    duplicate_count = 0
    unique_count = 0

    while unique_count < TOTAL_MESSAGES_EXPECTED:
        data, client_addr = sock.recvfrom(4096)
        packet = data.decode()

        try:
            seq_str, message = packet.split("|", 1)
            seq = int(seq_str)
        except ValueError:
            print(f"[SERVER] Malformed packet ignored: {packet}")
            continue

        if seq in received_seqs:
            duplicate_count += 1
            print(f"[SERVER] Duplicate packet SEQ={seq} received -> '{message}' (sending ACK again)")
        else:
            received_seqs.add(seq)
            unique_count += 1
            print(f"[SERVER] New packet SEQ={seq} received -> '{message}' "
                  f"(unique so far: {unique_count})")

        # Always ACK, whether it's new or duplicate (server must ack duplicates too,
        # since the original ACK was probably lost -- that's WHY the client resent it)
        ack = f"ACK|{seq}"
        sock.sendto(ack.encode(), client_addr)

    print("\n[SERVER] ---- FINAL RESULTS ----")
    print(f"TOTAL_UNIQUE_MESSAGES_RECEIVED={unique_count}")
    print(f"TOTAL_DUPLICATES_DETECTED={duplicate_count}")
    print("STATUS=SUCCESS")

    sock.close()


if __name__ == "__main__":
    main()
