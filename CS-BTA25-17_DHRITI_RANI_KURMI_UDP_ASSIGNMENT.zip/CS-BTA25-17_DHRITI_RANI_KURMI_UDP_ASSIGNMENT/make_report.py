"""
Generates report.pdf for the Reliable UDP assignment.
Run this AFTER you have run the experiments and filled in result_table.csv
and taken your screenshots. It will pull the real numbers from
result_table.csv automatically.

Usage:
    python3 make_report.py
"""

import csv
import os
from reportlab.lib.pagesizes import A4
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                 Table, TableStyle, Image)
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.units import cm

ROLL_NO = "CS-BTA25-17"
NAME = "Dhriti Rani Kurmi"
TIMEOUT = "1.2 seconds (roll number last digit = 7)"

styles = getSampleStyleSheet()
story = []

def h1(text):
    story.append(Paragraph(text, styles["Heading1"]))
    story.append(Spacer(1, 8))

def h2(text):
    story.append(Paragraph(text, styles["Heading2"]))
    story.append(Spacer(1, 6))

def body(text):
    story.append(Paragraph(text, styles["Normal"]))
    story.append(Spacer(1, 10))

# ---- Title ----
story.append(Paragraph("Reliable UDP Communication in Mininet", styles["Title"]))
story.append(Spacer(1, 4))
body(f"<b>Name:</b> {NAME}<br/><b>Roll Number:</b> {ROLL_NO}<br/>"
     f"<b>Timeout used:</b> {TIMEOUT}")

# ---- Topology ----
h1("1. Mininet Topology")
body("The experiment uses Mininet's default linear topology with one switch:")
body("<b>h1 (Server, 10.0.0.1) &mdash;&mdash; s1 &mdash;&mdash; h2 (Client, 10.0.0.2)</b>")
body("The topology was verified using the <i>nodes</i>, <i>net</i>, and <i>pingall</i> "
     "commands before running the client/server programs (see screenshots).")

# ---- Method ----
h1("2. Method: Stop-and-Wait Reliability")
body("The client (h2) sends 10 messages to the server (h1), one at a time. Each packet "
     "carries a sequence number in the format <b>SEQ|MESSAGE</b>. The server replies with "
     "<b>ACK|SEQ</b>. If the client does not receive the correct ACK within the timeout "
     f"period ({TIMEOUT}), it retransmits the same packet. The server detects duplicate "
     "sequence numbers and counts them separately from unique messages.")

# ---- Result Table ----
h1("3. Result Table")
csv_path = "result_table.csv"
if os.path.isfile(csv_path):
    with open(csv_path) as f:
        reader = list(csv.reader(f))
    if len(reader) > 1:
        table_data = reader
        t = Table(table_data, repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4a4a4a")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 6.5),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ]))
        story.append(t)
    else:
        body("<i>[No experiment rows found yet in result_table.csv. Run client.py three "
             "times (loss=0, loss=5, loss=10) inside Mininet, then re-run this script.]</i>")
else:
    body("<i>[result_table.csv not found. Run the experiments first.]</i>")

story.append(Spacer(1, 12))

# ---- Screenshots placeholder ----
h1("4. Screenshots")
body("<i>[Insert nodes.png, net.png, pingall.png, server_output.png and client_output.png "
     "from the screenshots/ folder here before final submission.]</i>")

# ---- Questions ----
h1("5. Questions")

h2("1. Why is ACK needed?")
body("An ACK (acknowledgement) tells the sender that a specific packet was received "
     "correctly by the other side. Since UDP itself gives no delivery guarantee, the "
     "client has no other way to know whether a message actually arrived. Without ACKs, "
     "the client could not distinguish between a successful transfer and a lost packet, "
     "so it would not know when it is safe to send the next message.")

h2("2. Why is timeout needed?")
body("Timeout gives the client a rule for how long to wait for an ACK before assuming "
     "the packet (or its ACK) was lost. Because UDP does not retransmit lost data on its "
     "own, the client must decide for itself when to give up waiting and resend the "
     "packet. Without a timeout the client could wait forever if a packet or ACK is "
     "dropped on the lossy link.")

h2("3. Why can duplicate messages occur?")
body("Duplicates occur when the client's ACK is lost, is delayed past the timeout, or is "
     "itself dropped by the lossy link. In that case, the client believes the original "
     "packet was lost and retransmits it, even though the server actually received it the "
     "first time. The server therefore receives the same sequence number twice, which it "
     "detects and counts as a duplicate.")

h2("4. What happens when packet loss increases?")
body("As the configured loss percentage on the link increases (0% &rarr; 5% &rarr; 10%), "
     "more data packets and/or ACKs are dropped in transit. This causes more timeouts, "
     "which increases the number of retransmissions and the total packets sent, and "
     "therefore increases the total transfer time. The number of duplicates detected at "
     "the server also tends to rise, since more ACKs are being lost even when the "
     "original data packet actually arrived.")

h2("5. How is this method similar to TCP?")
body("Like TCP, this method uses sequence numbers to identify packets, acknowledgements "
     "to confirm delivery, and a timeout-based retransmission mechanism to recover from "
     "loss. Both approaches turn an unreliable channel into one where the sender can "
     "detect and recover from lost data, and both can detect duplicate deliveries.")

h2("6. How is it different from TCP?")
body("This implementation is a simple Stop-and-Wait scheme: only one unacknowledged "
     "packet is ever in flight, whereas TCP uses sliding windows and can have many "
     "packets in flight at once for much higher throughput. TCP also provides connection "
     "setup/teardown (three-way handshake), congestion control, flow control, and "
     "in-order delivery guarantees at the transport layer, none of which are implemented "
     "here &mdash; this program adds only the minimum reliability logic on top of raw UDP.")

doc = SimpleDocTemplate("report.pdf", pagesize=A4,
                         topMargin=1.8*cm, bottomMargin=1.8*cm,
                         leftMargin=2*cm, rightMargin=2*cm)
doc.build(story)
print("report.pdf generated.")
