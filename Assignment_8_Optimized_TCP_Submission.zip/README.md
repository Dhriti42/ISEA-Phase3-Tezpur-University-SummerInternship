# Assignment 8 — Application Optimization, Scalability and Reliability

This submission continues the Assignment 7 secure TCP application. The
newline-delimited JSON protocol is unchanged. Assignment 8 adds bounded
thread management, configuration, disconnect cleanup, timeouts, automatic
client reconnect and reproducible performance measurements.

## Run it

```bash
python server.py
# In another terminal on a machine with Tkinter:
python client_gui.py
```

Runtime values are read from `config.json`. The default server port remains
`5000`, and the server allows 100 connected clients with a bounded pool of 32
workers. Demo credentials are `alice` / `Password123!`; only the SHA-256
digest is stored in `users.json`.

## Optimizations implemented

- **Connection management:** disconnected sockets are detected, removed from
  the active-client set and closed in `finally` cleanup; a configured capacity
  rejects excess clients with a meaningful response.
- **Reliability:** socket timeouts, graceful server shutdown, executor
  shutdown, GUI error messages and one automatic reconnect with
  re-authentication.
- **Scalability:** the server uses a bounded `ThreadPoolExecutor` rather than
  creating an unbounded thread for every accepted client.
- **Configuration:** host, port, capacity, worker count, message size,
  timeouts and lockout values are in `config.json`.
- **Measurement:** `performance_benchmark.py` runs three repetitions for 5, 8
  and 10 concurrent clients and records delay, throughput, CPU time and peak
  memory in `performance_results.csv`.

## Performance experiment

```bash
python performance_benchmark.py
python generate_graphs.py
```

The benchmark compares the Assignment 7 per-client-thread mode with the
Assignment 8 bounded-worker-pool mode. It uses real loopback TCP requests;
the CSV contains 18 measurements (two modes × three client counts × three
repetitions). Run it again in Mininet for the final network-specific evidence.

## Mininet and Wireshark

```bash
sudo mn --topo single,11
nodes
net
pingall
```

Test the server/client using 5, 8 and 10 concurrent clients. Capture normal
TCP operation in Wireshark with:

```text
tcp.port == 5000
```

The screenshots must be captured in the student's own Mininet/Wireshark
environment. `screenshots/README.txt` lists the required evidence.

## Files

| File | Purpose |
| --- | --- |
| `server.py` | Secure and scalable threaded TCP server |
| `client_gui.py` | GUI client with independent networking and reconnect |
| `config.json` | Runtime configuration |
| `performance_benchmark.py` | Actual concurrent-client benchmark |
| `performance_results.csv` | Generated measurements |
| `generate_graphs.py` | CSV-to-SVG graph generator |
| `graphs/` | Delay, throughput, CPU and memory graphs |
| `report.pdf` | Assignment 8 report |
| `reflection_answers_assignment8.txt` | Guide to copy by hand |

The handwritten reflection scan and Wireshark captures are not fabricated:
they must be added after the student performs the lab steps.