"""Generate simple SVG graphs directly from performance_results.csv."""

from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "performance_results.csv"
OUT = ROOT / "graphs"


def load_rows() -> list[dict[str, str]]:
    with RESULTS.open(encoding="utf-8", newline="") as source:
        return list(csv.DictReader(source))


def svg_bar_chart(rows, metric: str, label: str, filename: str) -> None:
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row["mode"], int(row["clients"]))].append(float(row[metric]))
    modes = list(dict.fromkeys(row["mode"] for row in rows))
    colors = ["#2f6fae", "#3b9b62"]
    width, height = 920, 500
    left, bottom, top = 85, 410, 75
    values = [sum(values) / len(values) for values in grouped.values()]
    maximum = max(values) if values else 1
    scale = (bottom - top) / maximum
    chunks = []
    for client_index, client_count in enumerate((5, 8, 10)):
        center = 200 + client_index * 250
        for mode_index, mode in enumerate(modes):
            key = (mode, client_count)
            if key not in grouped:
                continue
            value = sum(grouped[key]) / len(grouped[key])
            bar_height = max(2, value * scale)
            x = center - 55 + mode_index * 62
            y = bottom - bar_height
            chunks.append(
                f'<rect x="{x}" y="{y:.1f}" width="48" height="{bar_height:.1f}" '
                f'fill="{colors[mode_index % len(colors)]}"/>'
                f'<text x="{x + 24}" y="{y - 7:.1f}" text-anchor="middle" '
                f'class="value">{value:.2f}</text>'
            )
        chunks.append(
            f'<text x="{center}" y="440" text-anchor="middle" class="axis">'
            f'{client_count} clients</text>'
        )
    legend = "".join(
        f'<rect x="{650 + i * 125}" y="35" width="16" height="16" fill="{colors[i]}"/>'
        f'<text x="{672 + i * 125}" y="49" class="legend">{"Assignment 7" if i == 0 else "Assignment 8"}</text>'
        for i in range(len(modes))
    )
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">
<style>
  .title {{ font: 700 22px sans-serif; fill: #19324d; }}
  .axis {{ font: 16px sans-serif; fill: #243447; }}
  .value {{ font: 12px sans-serif; fill: #243447; }}
  .legend {{ font: 13px sans-serif; fill: #243447; }}
</style>
<rect width="100%" height="100%" fill="white"/>
<text x="460" y="30" text-anchor="middle" class="title">{label}</text>
<line x1="{left}" y1="{top}" x2="{left}" y2="{bottom}" stroke="#7894ad"/>
<line x1="{left}" y1="{bottom}" x2="875" y2="{bottom}" stroke="#7894ad"/>
{legend}
{''.join(chunks)}
</svg>"""
    (OUT / filename).write_text(svg, encoding="utf-8")


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = load_rows()
    svg_bar_chart(rows, "average_delay_ms", "Average request delay (ms)", "delay.svg")
    svg_bar_chart(rows, "throughput_requests_per_second", "Throughput (requests/second)", "throughput.svg")
    svg_bar_chart(rows, "cpu_time_ms", "CPU time for concurrent batch (ms)", "cpu.svg")
    svg_bar_chart(rows, "memory_kb", "Process peak memory (KB)", "memory.svg")
    print(f"Generated graphs in {OUT}")


if __name__ == "__main__":
    main()