"""Run repeatable 5/8/10-client performance experiments for Assignment 8."""

from __future__ import annotations

import csv
import json
import resource
import socket
import statistics
import tempfile
import threading
import time
from pathlib import Path

from server import SecureTCPServer, hash_password


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "performance_results.csv"


def read_response(file) -> dict:
    line = file.readline()
    if not line:
        raise ConnectionError("server closed connection")
    return json.loads(line)


def run_trial(client_count: int, optimized: bool) -> dict[str, float | int | str]:
    with tempfile.TemporaryDirectory() as temp_name:
        temp = Path(temp_name)
        users = {
            f"user{i:02d}": hash_password("Password123!")
            for i in range(client_count)
        }
        users_file = temp / "users.json"
        users_file.write_text(json.dumps(users))
        config = {
            "host": "127.0.0.1",
            "port": 0,
            "max_clients": 100,
            "worker_threads": 32,
            "max_message_length": 1024,
            "session_timeout_seconds": 300,
            "request_timeout_seconds": 1,
            "max_failed_attempts": 5,
            "lockout_seconds": 60,
        }
        server = SecureTCPServer(
            host="127.0.0.1", port=0, users_file=users_file,
            log_file=temp / "security_log.txt", config=config,
            use_thread_pool=optimized,
        )
        server.start()
        sockets: list[tuple[socket.socket, object]] = []
        try:
            for i in range(client_count):
                sock = socket.create_connection(("127.0.0.1", server.port), timeout=3)
                sock.settimeout(3)
                file = sock.makefile("r", encoding="utf-8")
                read_response(file)
                sock.sendall((
                    json.dumps({
                        "command": "login",
                        "username": f"user{i:02d}",
                        "password": "Password123!",
                    }) + "\n"
                ).encode())
                if not read_response(file).get("ok"):
                    raise RuntimeError("benchmark login failed")
                sockets.append((sock, file))

            barrier = threading.Barrier(client_count + 1)
            latencies: list[float] = []
            errors: list[str] = []
            result_lock = threading.Lock()

            def ping(index: int) -> None:
                try:
                    barrier.wait()
                    started = time.perf_counter()
                    sock, file = sockets[index]
                    sock.sendall(b'{"command":"ping"}\n')
                    response = read_response(file)
                    elapsed = (time.perf_counter() - started) * 1000
                    if response.get("ok"):
                        with result_lock:
                            latencies.append(elapsed)
                    else:
                        with result_lock:
                            errors.append("ping rejected")
                except Exception as exc:  # benchmark records failure, never hangs
                    with result_lock:
                        errors.append(type(exc).__name__)

            workers = [
                threading.Thread(target=ping, args=(i,), daemon=True)
                for i in range(client_count)
            ]
            before_cpu = resource.getrusage(resource.RUSAGE_SELF).ru_utime
            before_wall = time.perf_counter()
            for worker in workers:
                worker.start()
            barrier.wait()
            for worker in workers:
                worker.join(timeout=5)
            wall_seconds = time.perf_counter() - before_wall
            after_cpu = resource.getrusage(resource.RUSAGE_SELF).ru_utime
            if errors or len(latencies) != client_count:
                raise RuntimeError(f"trial failed: {errors}")
            return {
                "mode": "Assignment 8 bounded worker pool" if optimized
                else "Assignment 7 per-client threads",
                "clients": client_count,
                "average_delay_ms": round(statistics.mean(latencies), 3),
                "throughput_requests_per_second": round(client_count / wall_seconds, 3),
                "cpu_time_ms": round((after_cpu - before_cpu) * 1000, 3),
                "memory_kb": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            }
        finally:
            for sock, file in sockets:
                try:
                    file.close()
                except OSError:
                    pass
                try:
                    sock.close()
                except OSError:
                    pass
            server.stop()


def main() -> None:
    RESULTS.parent.mkdir(exist_ok=True)
    rows = []
    for optimized in (False, True):
        for client_count in (5, 8, 10):
            # Three samples per condition make the CSV less sensitive to one
            # scheduler hiccup while remaining quick to reproduce.
            for repetition in range(1, 4):
                row = run_trial(client_count, optimized)
                row["repetition"] = repetition
                rows.append(row)
                print(row)
    fieldnames = [
        "mode", "clients", "repetition", "average_delay_ms",
        "throughput_requests_per_second", "cpu_time_ms", "memory_kb",
    ]
    with RESULTS.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} measurements to {RESULTS}")


if __name__ == "__main__":
    main()