"""Generate the Assignment 8 report from the measured CSV data."""

from __future__ import annotations

import csv
import statistics
from collections import defaultdict

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table, TableStyle


OUTPUT = "report.pdf"
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(
    name="ReportTitle", parent=styles["Title"], alignment=TA_CENTER,
    textColor=colors.HexColor("#285d8f"), fontSize=18, leading=23, spaceAfter=10,
))
styles.add(ParagraphStyle(
    name="Section", parent=styles["Heading2"], textColor=colors.HexColor("#285d8f"),
    spaceBefore=9, spaceAfter=4,
))
styles.add(ParagraphStyle(
    name="Tiny", parent=styles["BodyText"], fontSize=8, leading=10,
))


def para(text: str, style: str = "BodyText") -> Paragraph:
    return Paragraph(text, styles[style])


def measurements() -> list[dict[str, str]]:
    with open("performance_results.csv", encoding="utf-8", newline="") as source:
        return list(csv.DictReader(source))


def average_table(rows: list[dict[str, str]]) -> list[list[str]]:
    grouped: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[(row["mode"], row["clients"])].append(row)
    result = [["Mode", "Clients", "Delay ms", "Throughput/s", "CPU ms", "Peak memory KB"]]
    for (mode, clients), samples in grouped.items():
        values = lambda name: statistics.mean(float(r[name]) for r in samples)
        short_mode = "A7 per-client threads" if mode.startswith("Assignment 7") else "A8 bounded pool"
        result.append([
            short_mode, clients,
            f"{values('average_delay_ms'):.3f}",
            f"{values('throughput_requests_per_second'):.1f}",
            f"{values('cpu_time_ms'):.3f}",
            f"{values('memory_kb'):.1f}",
        ])
    return result


rows = measurements()
table_data = average_table(rows)
doc = SimpleDocTemplate(
    OUTPUT, pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm,
    topMargin=14 * mm, bottomMargin=14 * mm,
    title="Assignment 8 Application Optimization Report",
)

story = [
    para("Assignment 8: Application Optimization, Scalability and Reliability", "ReportTitle"),
    para("ISEA Phase III Networking Internship — Tezpur University"),
    para("<b>Student:</b> ____________________ &nbsp;&nbsp; <b>Roll number:</b> ____________________"),
    para("<b>Repository:</b> ____________________"),
    para("Objective", "Section"),
    para("This work continues the secure TCP application from Assignment 7. The goal is to improve connection management, reliability, scalability, maintainability and software quality without changing the newline-delimited JSON communication protocol."),
    para("Scalability Improvements", "Section"),
    para("The original per-client thread behavior is retained as a benchmark comparison mode. The optimized server uses a bounded ThreadPoolExecutor with 32 workers and a configurable capacity of 100 clients. This prevents unbounded thread creation while supporting the required 5, 8 and 10 concurrent-client tests. Shared session state remains protected by a re-entrant lock."),
    para("Reliability Improvements", "Section"),
    para("Disconnected clients are removed from the client registry and authenticated-session table in finally cleanup. Socket read timeouts prevent indefinitely blocked handlers. The client reports meaningful errors and attempts up to three reconnects with backoff; after reconnecting it re-authenticates in memory and retries the original request once. Server shutdown closes the listener and clients and waits for the worker pool to terminate."),
    para("Configuration Management", "Section"),
    para("The following values were moved to config.json: host, port, maximum clients, worker count, message size, session timeout, request timeout, failed-attempt limit and lockout duration. The server validates that numeric settings are positive integers and supplies defaults on first run."),
    para("Experimental Setup", "Section"),
    para("The benchmark starts the server on loopback TCP with isolated temporary user data, creates unique authenticated clients, synchronizes them with a barrier, and sends concurrent ping requests. Three repetitions were performed for 5, 8 and 10 clients in both the Assignment 7 per-client-thread mode and the Assignment 8 bounded-worker-pool mode. Delay is measured around each request; throughput is the concurrent batch rate; CPU time uses resource.getrusage(); memory is the process peak resident set size."),
    Preformatted("python performance_benchmark.py\npython generate_graphs.py", styles["Code"]),
    para("Performance Results", "Section"),
    Table(table_data, colWidths=[39 * mm, 15 * mm, 22 * mm, 28 * mm, 20 * mm, 27 * mm], repeatRows=1, style=TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dceaf7")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#7894ad")),
        ("FONTSIZE", (0, 0), (-1, -1), 7.1),
        ("LEADING", (0, 0), (-1, -1), 8.5),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ])),
    para(f"The CSV contains {len(rows)} actual measurements. Four SVG graphs were generated in graphs/: delay, throughput, CPU and memory.", "Tiny"),
    para("Graph Analysis", "Section"),
    para("On the local loopback experiment, the bounded worker pool produced lower mean delay for 8 and 10 clients and lower mean CPU time at 8 and 10 clients. At 5 clients the two modes were close, and the per-client-thread mode was marginally faster. This is expected for a low-load loopback test: thread-pool benefits become more visible as connection count and scheduling pressure increase. The 10-client run completed without crashes in both modes."),
    para("Wireshark Verification", "Section"),
    para("Use the Mininet topology sudo mn --topo single,11 and the display filter tcp.port == 5000. Capture normal authenticated communication, a reconnect after a transient disconnect, and the 5/8/10-client operation. The actual packet screenshots must be added from the student's lab environment; they are not fabricated in this report."),
    para("Challenges Faced", "Section"),
    para("The main design challenge was recovering a dropped TCP connection without redesigning the protocol or sending a request twice. The solution re-authenticates once after reconnecting and retries only the failed request. Another challenge was coordinating shutdown: the listener, sockets, session registry and bounded executor all need to be released in a predictable order."),
    para("Conclusion", "Section"),
    para("Assignment 8 improves the Assignment 7 application through bounded concurrency, configuration management, cleanup, timeouts, reconnect handling and measured performance. Before final submission, run the experiment in Mininet, add Wireshark/GUI screenshots, update the required GitHub repository naming convention and attach the handwritten reflection scan."),
]
doc.build(story)
print(OUTPUT)